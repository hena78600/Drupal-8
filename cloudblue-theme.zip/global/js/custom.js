
$(window).resize(function(){location.reload();});
$(document).ready(function(){
  $(window).scroll(function(){
    if ($(window).scrollTop() >= 300) {
        $('header').addClass('fixed-header');
    }
    else {
        $('header').removeClass('fixed-header');
    }
});

/* header menu for responsive*/
    $('a.toggle-menu').click(function(){
        $('header nav ul').toggle();
        $('header nav ul ul').hide();
    });
    /* header menu for responsive end*/

    $('.side-nav li a').click(function(){
      $('.side-nav li a').removeClass('active');
      $(this).addClass('active');
      // var tagid = $(this).data('tag');
      // $('.tabContent').removeClass('tabActive').addClass('tabHide');
      // $('#'+tagid).addClass('tabActive').removeClass('tabHide');
  });



  var offset = $(".side-nav").offset();
  var topPadding = 80;
  $(window).scroll(function() {
      if ($(window).scrollTop() > offset.top) {
          $(".side-nav").stop().animate({
              marginTop: $(window).scrollTop() - offset.top + topPadding
              
          });
      } else {
          $(".side-nav").stop().animate({
              marginTop: 0
          });
      };
  });



    $('#hideCookies').click(function(){
      $('#cookies').addClass('cookieshide');
  });

    $('.counter').each(function() {
        var $this = $(this),
            countTo = $this.attr('data-count');
        
        $({ countNum: $this.text()}).animate({
          countNum: countTo
        },
      
        {
      
          duration: 1000,
          easing:'linear',
          step: function() {
            $this.text(Math.floor(this.countNum));
          },
          complete: function() {
            $this.text(this.countNum);
            //alert('finished');
          }
      
        });  
        
        
      
      });


      if ($(window).width() <= 992){
        $('div').removeClass('d-flex');
        $('div').removeClass('p-0');
        $('div').removeClass('p-60'); 
        $('div').removeClass('p-30-lr');
        $('#videoSection').removeClass('padding-large');
        $('#videoSection').addClass('padding-large-bottom');
        $('.cleardiv').remove();
      };

      /* header menu for responsive*/

      if ($(window).width() <= 767){
        var offset = '';
        $('ul li a.next-submenu').each(function(){
          $(this).click(function(){
            $(this).next('ul.submenu').slideToggle();
            $('ul.submenu').not($(this).next('ul.submenu')).slideUp();
            $('ul.submenu-lvl2').slideUp();
          });

         
        });

        $('ul li.next-submenu-lvl2').find('a').each(function(){
          $(this).click(function(e){
            e.stopPropagation();
            $(this).next('ul.submenu-lvl2').slideToggle();
            $('ul.submenu-lvl2').not($(this).next('ul.submenu-lvl2')).slideUp();
          });
        });

      
      };
/* header menu for responsive End*/



      $('.customer-logos').slick({
        slidesToShow: 6,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1000,
        arrows: false,
        dots: false,
        pauseOnHover: false,
        responsive: [{
          breakpoint: 768,
          settings: {
            slidesToShow: 3
          }
        }, {
          breakpoint: 520,
          settings: {
            slidesToShow: 1
          }
        }]
      });

      $('*[draggable!=true]','.slick-track').unbind('dragstart');
    $( ".draggable-element" ).draggable();

    $(".draggable-element").on("draggable mouseenter mousedown",function(event){
      event.stopPropagation();
  });

     
  });

/* Added on 13Jan 2020 - Sandip   */

$(document).ready(function(){
if ($('.box-content').length) {
  $('.box-content').matchHeight();
}

if ($('.partner-box').length) {
  $('.partner-box').matchHeight();
}

if ($('.same-height').length) {
  $('.same-height').matchHeight();
}

if ($('.counterUp').length) {
  $('.counterUp .counterSection').matchHeight();
}

if ($('.home-box').length) {
  $('.home-box').matchHeight();
}

if ($('.article').length) {
  $('.article').matchHeight();
}


if ($('.slidingContent .item').length) {
  $('.slidingContent .item .item-content').matchHeight();
}


});



$(function() {
  'use strict';

  var $swipeTabsContainer = $('.swipe-tabs'),
      $swipeTabs = $('.swipe-tab'),
      $swipeTabsContentContainer = $('.swipe-tabs-container'),
      currentIndex = 0,
      activeTabClassName = 'active-tab';

  $swipeTabsContainer.on('init', function(event, slick) {
      $swipeTabsContentContainer.removeClass('invisible');
      $swipeTabsContainer.removeClass('invisible');

      currentIndex = slick.getCurrent();
      $swipeTabs.removeClass(activeTabClassName);
      $('.swipe-tab[data-slick-index=' + currentIndex + ']').addClass(activeTabClassName);
  });

  $swipeTabsContainer.slick({
      //slidesToShow: 3.25,
      slidesToShow: 4,
      slidesToScroll: 1,
      arrows: false,
      infinite: false,
      swipeToSlide: true,
      touchThreshold: 10
  });

  $swipeTabsContentContainer.slick({
      asNavFor: $swipeTabsContainer,
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: false,
      infinite: false,
      swipeToSlide: true,
      draggable: true,
      touchThreshold: 10
  });

  $swipeTabs.on('click', function(event) {
      // gets index of clicked tab
      currentIndex = $(this).data('slick-index');
      $swipeTabs.removeClass(activeTabClassName);
      $('.swipe-tab[data-slick-index=' + currentIndex + ']').addClass(activeTabClassName);
      $swipeTabsContainer.slick('slickGoTo', currentIndex);
      $swipeTabsContentContainer.slick('slickGoTo', currentIndex);
  });

  //initializes slick navigation tabs swipe handler
  $swipeTabsContentContainer.on('swipe', function(event, slick, direction) {
      currentIndex = $(this).slick('slickCurrentSlide');
      $swipeTabs.removeClass(activeTabClassName);
      $('.swipe-tab[data-slick-index=' + currentIndex + ']').addClass(activeTabClassName);
  });
});

$(document).ready(function() {
  $('.next-btn').click(function() {
      $('.swipe-tabs .swipe-tab.active-tab').next('div').trigger('click');
  });

  $('.previous-btn').click(function() {
      $('.swipe-tabs .swipe-tab.active-tab').prev('div').trigger('click');
  });
  $('.slick-list').addClass('w-100');
  $('.swipe-tabs-container .slick-list').addClass('overflowHidden');
  $('.swipe-tabs .slick-list').css('overflow', 'hidden');

  $('label.radio-yes').click(function(){
    $('.switch-field ').css('border-color','#2B4EF8');
  });

  $('label.radio-no').click(function(){
    $('.switch-field ').css('border-color','#B5B5B5');
  });

  var owl = $('#counterSection');
  owl.owlCarousel({
    margin: 10,
    loop: false,
    responsive: {
      0: {
        items: 1,
        dots: true
      },
      600: {
        items: 1
      },
      1000: {
        items: 3
      }
    }
  });


  var owl = $('.slidingContent');
  owl.owlCarousel({
    margin: 12,
    loop: false,
    responsive: {
      0: {
        items: 1,
        dots: false,
        nav: true
      },
      600: {
        items: 3
      },
      1000: {
        items: 5
      }
    }
  });


  var owl = $('.groupContent');
  owl.owlCarousel({
    animateOut: 'fadeOutUp',
    animateIn: 'fadeInUp',
    items:1,
    mouseDrag:false,
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
            nav:false,
            animateOut: false,
            animateIn: false
        },
        600:{
            items:1,
            nav:false,
            animateOut: false,
            animateIn: false
        },

        1000:{
          items:1,
          nav:false,
          animateOut: 'fadeOutUp',
          animateIn: 'fadeInUp',
      }
    }
    
  });


  /*Accordion  */
  $('.accordionHeading').click(function(){
    $(this).next('.accordionContent').slideDown();
    $(this).addClass('active');

    $('.accordionHeading.active').next('.accordionContent').not($(this).next('.accordionContent')).slideUp();
    $('.accordionHeading.active').not($(this)).removeClass('active');
  });

   /*Form Input  */
   $('.form-group input').each(function(){
     $(this).focus(function(){
        $(this).prev('label').addClass('placeHolder')
     });

     $(this).blur(function(){
      $(this).prev('label').removeClass('placeHolder');

      if($(this).val()){
        $(this).prev('label').addClass('placeHolder');
      }
   
     
   });

    
   });




 $('.tabLinks li').click(function(){
  $('.tabLinks li').removeClass('active');
  $(this).addClass('active');
  var tagid = $(this).data('tag');
  $('.listContent').removeClass('activeDiv').addClass('hide');
  $('#'+tagid).addClass('activeDiv').removeClass('hide');
});

});
