<?php

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Theme\ThemeSettings;
use Drupal\system\Form\ThemeSettingsForm;
use Drupal\Core\Form;


function global_form_system_theme_settings_alter(&$form, Drupal\Core\Form\FormStateInterface $form_state){

  // Contact info
  $form['global_contact'] = array(
    '#type' => 'details',
    '#title' => t('Contact Info In Top Header'),
    '#description' => t('Contact information is displayed in the Top Header'),
    '#weight' => -999,
    '#open' => FALSE,
  );
  // Phone etails
  $form['global_contact']['global_contact_phone'] = array(
    '#type' => 'textfield',
    '#title' => t('Phone'),
    '#description' => t('Appears above contact information'),
    '#default_value' => theme_get_setting('global_contact_phone'),
  );
 
  // Contact info
  $form['global_footer_contact'] = array(
    '#type' => 'details',
    '#title' => t('Footer Section'),
    '#description' => t('Contact information is displayed in the Footer'),
    '#weight' => -999,
    '#open' => FALSE,
  );
  // Phone etails
  $form['global_footer_contact']['global_footer_contact_number'] = array(
    '#type' => 'textfield',
    '#title' => t('Footer Contact Number'),
    '#description' => t('Appears in footer'),
    '#default_value' => theme_get_setting('global_footer_contact_number'),
  );
  $form['global_footer_contact']['global_footer_youtube'] = array(
    '#type' => 'textfield',
    '#title' => t('Youtube Link'),
    '#description' => t('Appears in footer'),
    '#default_value' => theme_get_setting('global_footer_youtube'),
  );
  $form['global_footer_contact']['global_footer_twitter'] = array(
    '#type' => 'textfield',
    '#title' => t('Twitter Link'),
    '#description' => t('Appears in footer'),
    '#default_value' => theme_get_setting('global_footer_twitter'),
  );
  $form['global_footer_contact']['global_footer_linkedin'] = array(
    '#type' => 'textfield',
    '#title' => t('Linked In Link'),
    '#description' => t('Appears in footer'),
    '#default_value' => theme_get_setting('global_footer_linkedin'),
  );
  $form['global_footer_contact']['global_copyright'] = array(
    '#type' => 'textfield',
    '#title' => t('Footer Copyright'),
    '#description' => t('Appears in footer'),
    '#default_value' => theme_get_setting('global_copyright'),
  );
  /* Footer Logo */
  $form['global_footer_contact']['global_theme_settings']['website'] = array(
    '#type' => 'details',
    '#title' => t('Upload Footer Logo'),
  );
  /*$form['global_footer_contact']['my_custom_theme_settings']['website']['banner_image_url'] = array(
    '#type' => 'textfield',
    '#title' => t('Banner Image Url'),
    '#default_value' => theme_get_setting('banner_image_url'),
  );*/
  $form['global_footer_contact']['global_theme_settings']['website']['footer_logoimage_path'] = array(
    '#type' => 'managed_file',
    '#title' => t('Footer Logo Image'),
    '#default_value' => theme_get_setting('footer_logoimage_path'),
    '#upload_location' => 'public://',
  );


  // Make the uploaded images permanent.
    $image = theme_get_setting('footer_logoimage_path','global_theme');
    if(!empty($image)){
      $file = File::load($image);
      $file->status = FILE_STATUS_PERMANENT;
      $file->save();
      $file_usage = \Drupal::service('file.usage');
      $file_usage_check = $file_usage->listUsage($file);
      if (empty($file_usage_check)) {
        $file_usage->add($file, 'global_theme', 'theme', $image);
      }
    }
  
   
}
