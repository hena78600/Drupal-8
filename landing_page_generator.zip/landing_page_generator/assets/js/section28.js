const section28 = {"show_properties":{
    "body":{"elements": {
        0: {"properties":{"html":{"value":"","type":"single","widget":"editor","selected":"","label":"Body"}},"machine_name":"body","wrapper":"none"}
      },"element_type":"single","label": "Body","machine_name":"body_master","wrapper":"none"},
  },
    "internal_properties":{"type":"section1","html":""}};
