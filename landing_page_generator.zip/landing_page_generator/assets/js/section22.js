const section22 = {"show_properties":{
        "background":{"elements":{
                0:{"properties":{"text":{"value":"Testing","type":"single","widget":"select","selected":"","label":"Background","option":{"background-gradient-purple":"Purple","background-gradient-light-blue":"Light Blue","background-gradient-dark-blue":"Dark Blue","background-black":"Black","background-dark-brown":"Dark Brown","background-light":"Light","background-white":"White"}}},"machine_name":"background_master","wrapper":"none"},
            },"element_type":"single","label":"Background","machine_name":"background_master","wrapper":"none"},

        "heading":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Heading"}},"machine_name":"heading","wrapper":"none"},
    },"element_type":"single","label":"Heading","machine_name":"heading_master","wrapper":"none"},
    "body":{"elements": {
       0: {"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Body"}},"machine_name":"body","wrapper":"none"}
    },"element_type":"single","label": "Body","machine_name":"body_master","wrapper":"none"},
    "videos":{"elements":{
        0:{"properties":{"text" : {"value":"","type":"single","widget":"text","selected":"","label":"Youtube Link","machine_name":"youtube_link"}},"label":"Youtube Link","machine_name":"youtube_link","wrapper":"<iframe width=\"100%\" height=\"315\" src=\"[CONTENT]\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen=\"\"></iframe>"},
      },"element_type":"multiple","label":"Videos","machine_name":"videos_master","wrapper":"<div class=\"col-lg-6\"><div class=\"landing-box\"><div class=\"landing-box-content\">[CONTENT]</div></div></div>"},
    },
    "internal_properties":{"type":"section1","html":""}};
