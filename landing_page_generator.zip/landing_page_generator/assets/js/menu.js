const menu = {"show_properties":{
        "menu_left_logo":{"elements": {
                0: {"properties":{"html":{"value":"","type":"single","widget":"image","selected":"","label":"Menu Left Logo"}},"machine_name":"menu_left_logo","wrapper":"none"}
            },"element_type":"single","label": "Image","machine_name":"menu_left_logo","wrapper":"none"},
        "menu_link":{"elements":{
                0:{"properties":{"val":{"value":"Program Packages","type":"single","widget":"text","selected":"","label":"Text","machine_name":"button_text"},
                        "href":{"value":"","type":"single","widget":"text","selected":"","label":"Link"}
                    },"label":"Menu Link","machine_name":"card_button","wrapper":"<a  href=\"[LINK]\">[CONTENT]</a>"}
            },"element_type":"multiple","label":"Card","machine_name":"menu_link","wrapper":"<li>[CONTENT]</li>"},
        "menu_right_logo":{"elements": {
                0: {"properties":{"html":{"value":"","type":"single","widget":"image","selected":"","label":"Menu Right Logo"}},"machine_name":"menu_right_logo","wrapper":"none"}
            },"element_type":"single","label": "Image","machine_name":"menu_right_logo","wrapper":"none"},


    },
    "internal_properties":{"type":"section1","html":""}};
