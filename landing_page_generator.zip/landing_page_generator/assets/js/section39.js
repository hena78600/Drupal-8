const section39 = {"show_properties":{
    "background":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"select","selected":"","label":"Background","option":{"background-gradient-purple":"Purple","background-gradient-light-blue":"Light Blue","background-gradient-dark-blue":"Dark Blue","background-black":"Black","background-dark-brown":"Dark Brown","background-light":"Light","background-white":"White"}}},"machine_name":"background_master","wrapper":"none"},
      },"element_type":"single","label":"Background","machine_name":"background_master","wrapper":"none"},

    "heading":{"elements":{
                0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Heading"}},"machine_name":"heading","wrapper":"<h2>[CONTENT]</h2>"},
            },"element_type":"single","label":"Heading","machine_name":"heading_master","wrapper":"[CONTENT]"},
        "body":{"elements": {
                0: {"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Body"}},"machine_name":"body","wrapper":"none"}
            },"element_type":"single","label": "Body","machine_name":"body_master","wrapper":"none"},
    "button_1":{"elements":{
        0:{"properties":{"val":{"value":"Program Packages","type":"single","widget":"text","selected":"","label":"Text","machine_name":"button_text_1"},
            "href":{"value":"","type":"single","widget":"text","selected":"","label":"Link"}
          },"label":"Button 1","machine_name":"button1","wrapper":"<a class=\"btn btn-secondary btn-sm\" href=\"[LINK]\">[CONTENT]</a>"},"machine_name":"button1","wrapper":"none"
      },"element_type":"single","label":"Button 1","machine_name":"button_master_1","wrapper":"none"},
    "button_2":{"elements":{
        0:{"properties":{"val":{"value":"Program Packages","type":"single","widget":"text","selected":"","label":"Text","machine_name":"button_text_2"},
            "href":{"value":"","type":"single","widget":"text","selected":"","label":"Link"}
          },"label":"Button 2","machine_name":"button2","wrapper":"<a class=\"btn btn-secondary btn-sm\" href=\"[LINK]\">[CONTENT]</a>"},"machine_name":"button2","wrapper":"none"
      },"element_type":"single","label":"Button 1","machine_name":"button_master_2","wrapper":"none"}

  },
    "internal_properties":{"type":"section1","html":""}};
