var sub_section = {"show_properties":{
    "width":{"value": {"col-md-1":"8.33%","col-md-2":"16.66%","col-md-3":"25%","col-md-4":"33.33","col-md-5":"41.66",
                "col-md-6":"50%","col-md-7":"58.33%","col-md-8":"66.66","col-md-9":"75%","col-md-10":"83.33%","col-md-11":"91.66%","col-md-12":"100%"},
        "type":"multi","selected":"col-md-1","widget":"select","label":"Width"},
    "padding":{"value":{"none":"None","pd0":0,"pd5":5,"pd10":10,"pd15":15,"pd20":20,"pd25":25,"pd30":30,"pd35":35,
                "pd40":40,"pd45":45,"pd50":50},"type":"multi","selected":"none","widget":"select","label":"Padding"},
    "align":{"value":{"none":"none","content-left":"Left","content-center":"Center","content-right":"Right"}
            ,"type":"multi","selected":"none","widget":"select","label":"Align"}},"internal_properties":{"type":"sub_section","html":"<div class='sub-section col-md-1' id='[ID]' data-type='sub_section' tabindex='[INDEX]'></div>"}};