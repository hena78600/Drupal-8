const section17 = {"show_properties":{
    "background":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"select","selected":"","label":"Background","option":{"background-gradient-purple":"Purple","background-gradient-light-blue":"Light Blue","background-gradient-dark-blue":"Dark Blue","background-black":"Black","background-dark-brown":"Dark Brown","background-light":"Light","background-white":"White"}}},"machine_name":"background_master","wrapper":"none"},
      },"element_type":"single","label":"Background","machine_name":"background_master","wrapper":"none"},

    "section_heading":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Section Heading"}},"machine_name":"section_heading_master","wrapper":"none"},
    },"element_type":"single","label":"Section Heading","machine_name":"section_heading_master","wrapper":"none"},

    "text_slider":{"elements":{
        0:{"properties":{"html":{"value":"","type":"single","widget":"image","selected":"","label":"Logo Image"}},"machine_name":"logo_image","wrapper":"<div class=\"facilities-box-image\"><img class=\"img-responsive\" src='[CONTENT]'></div><div class=\"facilities-box-content\">"},
        1:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Card Heading"}},"machine_name":"card_heading","wrapper":"<div class=\"facilities-tag\"><h4>[CONTENT]</h4></div>"},
        2:{"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Card Body","machine_name":"card_body"}},"label":"Card Body","machine_name":"card_body","wrapper":"<p>[CONTENT]</p></div>"},
    },"element_type":"multiple","label":"Card","machine_name":"card_master","wrapper":"<div class=\"col-lg-5 offset-lg-1\"><div class=\"facilities-box\">[CONTENT]</div></div>"},
    "button":{"elements":{
                0:{"properties":{"val":{"value":"Program Packages","type":"single","widget":"text","selected":"","label":"Text","machine_name":"button_text"},
                        "href":{"value":"","type":"single","widget":"text","selected":"","label":"Link"}
                    },"label":"Button","machine_name":"button","wrapper":"<a href='[LINK]' class=\"btn btn-secondary btn-lg mt-30\">[CONTENT]</a>"},"machine_name":"button","wrapper":"none"
            },"element_type":"single","label":"Button","machine_name":"button_master","wrapper":"none"}
    },
    "internal_properties":{"type":"section1","html":""}};
