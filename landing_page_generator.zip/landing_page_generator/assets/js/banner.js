const banner = {"show_properties":{
    "heading":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Banner Heading"}},"machine_name":"banner_heading","wrapper":"none"},
    },"element_type":"single","label":"Heading","machine_name":"banner_heading","wrapper":"none"},
    "body":{"elements": {
       0: {"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Banner Body"}},"machine_name":"body","wrapper":"none"}
    },"element_type":"single","label": "Body","machine_name":"body_master","wrapper":"none"},
    "banner_image":{"elements": {
        0: {"properties":{"html":{"value":"","type":"single","widget":"image","selected":"","label":"Banner Image"}},"machine_name":"banner_image","wrapper":"none"}
      },"element_type":"single","label": "Banner Image","machine_name":"banner_image","wrapper":"none"},
    "banner_logo":{"elements": {
        0: {"properties":{"html":{"value":"","type":"single","widget":"image","selected":"","label":"Banner Logo"}},"machine_name":"banner_logo","wrapper":"<img src=\"[CONTENT]\" class=\"img-responsive\">"}
      },"element_type":"single","label": "Banner Image","machine_name":"banner_logo","wrapper":"[CONTENT]"},

    "button":{"elements":{
        0:{"properties":{"val":{"value":"Program Packages","type":"single","widget":"text","selected":"","label":"Text","machine_name":"button_text"},
            "href":{"value":"","type":"single","widget":"text","selected":"","label":"Link"}
          },"label":"Button","machine_name":"button","wrapper":"<a class=\"btn btn-secondary btn-lg\" href=\"[LINK]\">[CONTENT]</a>"},"machine_name":"button","wrapper":"none"
      },"element_type":"single","label":"Banner Button","machine_name":"button_master","wrapper":"none"}


  },
    "internal_properties":{"type":"section1","html":""}};
