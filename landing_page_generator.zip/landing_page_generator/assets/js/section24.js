const section24 = {"show_properties":{
    "background":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"select","selected":"","label":"Background","option":{"background-gradient-purple":"Purple","background-gradient-light-blue":"Light Blue","background-gradient-dark-blue":"Dark Blue","background-black":"Black","background-dark-brown":"Dark Brown","background-light":"Light","background-white":"White"}}},"machine_name":"background_master","wrapper":"none"},
      },"element_type":"single","label":"Background","machine_name":"background_master","wrapper":"none"},

    "section_heading":{"elements":{
                0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Section Heading"}},"machine_name":"section_heading_master","wrapper":"none"},
            },"element_type":"single","label":"Section Heading","machine_name":"section_heading_master","wrapper":"none"},
        "sub_heading":{"elements":{
                0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Sub Heading"}},"machine_name":"sub_heading","wrapper":"none"},
            },"element_type":"single","label":"Sub Heading","machine_name":"sub_heading","wrapper":"none"},

        "body":{"elements": {
                0: {"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Body"}},"machine_name":"body","wrapper":"none"}
            },"element_type":"single","label": "Body","machine_name":"body_master","wrapper":"none"},
        "point_heading":{"elements":{
                0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Point Heading"}},"machine_name":"point_heading","wrapper":"none"},
            },"element_type":"single","label":"Point Heading","machine_name":"point_heading","wrapper":"none"},

        "item_master":{"elements":{
                0:{"properties":{"html":{"value":"","type":"single","widget":"image","selected":"","label":"Item Image"}},"machine_name":"item_image","wrapper":"<img src=\"[CONTENT]\"><div>"},
                1:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Point Title"}},"machine_name":"point_title","wrapper":"<h3>[CONTENT]</h3>"},
                2:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Point Description"}},"machine_name":"point_description","wrapper":"<p>[CONTENT]</p></div>"},

            },"element_type":"multiple","label":"Item","machine_name":"item_master","wrapper":"<div class=\"ingram-micro-partner-benefit\">[CONTENT]</div>"},
    },
    "internal_properties":{"type":"section1","html":""}};
