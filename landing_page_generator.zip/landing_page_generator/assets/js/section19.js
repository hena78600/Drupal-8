const section19 = {"show_properties":{
    "background":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"select","selected":"","label":"Background","option":{"background-gradient-purple":"Purple","background-gradient-light-blue":"Light Blue","background-gradient-dark-blue":"Dark Blue","background-black":"Black","background-dark-brown":"Dark Brown","background-light":"Light","background-white":"White"}}},"machine_name":"background_master","wrapper":"none"},
      },"element_type":"single","label":"Background","machine_name":"background_master","wrapper":"none"},

    "section_heading":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Section Heading"}},"machine_name":"section_heading_master","wrapper":"none"},
    },"element_type":"single","label":"Section Heading","machine_name":"section_heading_master","wrapper":"none"},
    "body":{"elements": {
        0: {"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Body"}},"machine_name":"body","wrapper":"none"}
      },"element_type":"single","label": "Body","machine_name":"body_master","wrapper":"none"},

    "list_master":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"List Heading"}},"machine_name":"list_heading","wrapper":"<li>[CONTENT]</li>"},
    },"element_type":"multiple","label":"List","machine_name":"list_master","wrapper":"[CONTENT]"},
    "box_section_heading":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Right Box Heading"}},"machine_name":"box_section_heading_master","wrapper":"none"},
      },"element_type":"single","label":"Section Heading","machine_name":"box_section_heading_master","wrapper":"none"},
    "box_body":{"elements": {
        0: {"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Right Box Body"}},"machine_name":"box_body","wrapper":"none"}
      },"element_type":"single","label": "Right Box Body","machine_name":"box_body_master","wrapper":"none"},

    "button":{"elements":{
                0:{"properties":{"val":{"value":"Program Packages","type":"single","widget":"text","selected":"","label":"Text","machine_name":"button_text"},
                        "href":{"value":"","type":"single","widget":"text","selected":"","label":"Link"}
                    },"label":"Button","machine_name":"button","wrapper":"<a href='[LINK]' class=\"btn btn-light btn-sm mt-10\">[CONTENT]</a>"},"machine_name":"button","wrapper":"none"
            },"element_type":"single","label":"Button","machine_name":"button_master","wrapper":"none"}
    },
    "internal_properties":{"type":"section1","html":""}};
