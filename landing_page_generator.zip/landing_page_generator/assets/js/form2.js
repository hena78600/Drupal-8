const form2 = {"show_properties":{
    "eloqua_id":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Eloqua Id"}},"machine_name":"eloqua_id","wrapper":"<input type='hidden' name='elqSiteId' value='[CONTENT]' />"},
      },"element_type":"single","label":"Eloqua Id","machine_name":"eloqua_id","wrapper":"[CONTENT]"},
    "form_name":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Form Name"}},"machine_name":"form_name","wrapper":"<input type='hidden' name='elqFormName' value='[CONTENT]' />"},
      },"element_type":"single","label":"Form Name","machine_name":"form_name","wrapper":"[CONTENT]"},
    "action":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Form Action"}},"machine_name":"action","wrapper":"none"},
      },"element_type":"single","label":"Form Action","machine_name":"action","wrapper":"none"},
    "image":{"elements": {
        0: {"properties":{"html":{"value":"","type":"single","widget":"image","selected":"","label":"Image"}},"machine_name":"image","wrapper":"none"}
      },"element_type":"single","label": "Image","machine_name":"image","wrapper":"none"},

  },
    "internal_properties":{"type":"section1","html":""}};
