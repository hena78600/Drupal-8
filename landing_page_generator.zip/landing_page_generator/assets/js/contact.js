const contact = {"show_properties":{
    "heading":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Heading"}},"machine_name":"heading","wrapper":"none"},
    },"element_type":"single","label":"Heading","machine_name":"heading_master","wrapper":"none"},
    "body":{"elements": {
       0: {"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Body"}},"machine_name":"body","wrapper":"none"}
    },"element_type":"single","label": "Body","machine_name":"body_master","wrapper":"none"},
    "contact_image":{"elements": {
        0: {"properties":{"html":{"value":"","type":"single","widget":"image","selected":"","label":"Image"}},"machine_name":"contact_image","wrapper":"none"}
      },"element_type":"single","label": "Contact Image","machine_name":"contact_image","wrapper":"none"},
  },
    "internal_properties":{"type":"section1","html":""}};
