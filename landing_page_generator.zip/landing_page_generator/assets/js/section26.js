const section26 = {"show_properties":{
    "background":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"select","selected":"","label":"Background","option":{"background-gradient-purple":"Purple","background-gradient-light-blue":"Light Blue","background-gradient-dark-blue":"Dark Blue","background-black":"Black","background-dark-brown":"Dark Brown","background-light":"Light","background-white":"White"}}},"machine_name":"background_master","wrapper":"none"},
      },"element_type":"single","label":"Background","machine_name":"background_master","wrapper":"none"},

    "section_image":{"elements": {
        0: {"properties":{"html":{"value":"","type":"single","widget":"image","selected":"","label":"Section Image"}},"machine_name":"section_image","wrapper":"none"}
      },"element_type":"single","label": "Image","machine_name":"section_image","wrapper":"none"},

    "section_heading":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Section Heading"}},"machine_name":"section_heading","wrapper":"none"},
    },"element_type":"single","label":"Section Heading","machine_name":"section_heading","wrapper":"none"},
    "body":{"elements": {
        0: {"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Body"}},"machine_name":"body","wrapper":"none"}
      },"element_type":"single","label": "Body","machine_name":"body_master","wrapper":"none"},

  },
    "internal_properties":{"type":"section1","html":""}};
