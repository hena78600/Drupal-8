//var button = {"type": "button","html": "<input type='button' value='Test1' data-type='button' id='test1' />","value": "Test1","id": ""};
var button = {"show_properties":{
    "val": {"value" : "Test1","type":"single","selected":"","widget":"textbox","label":"Value"},
    "id": {"value":"","type":"single","selected":"","widget":"textbox","label":"Id"},
    "color":{"value":{"none":"none","btn-primary":"Primary","btn-warning":"Warning","btn-success":"Success","btn-info":"Info","btn-danger":"Danger"},"type":"multi","selected":"none","widget":"select","label":"Color"}},
    "internal_properties":{"type": "button","html": "<input type='button' value='Test1' class='btn' data-type='button' id='[ID]' />",}};