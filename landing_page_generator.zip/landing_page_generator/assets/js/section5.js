const section5 = {"show_properties":{
        "background":{"elements":{
                0:{"properties":{"text":{"value":"Testing","type":"single","widget":"select","selected":"","label":"Background","option":{"background-gradient-purple":"Purple","background-gradient-light-blue":"Light Blue","background-gradient-dark-blue":"Dark Blue","background-black":"Black","background-dark-brown":"Dark Brown","background-light":"Light","background-white":"White"}}},"machine_name":"background_master","wrapper":"none"},
            },"element_type":"single","label":"Background","machine_name":"background_master","wrapper":"none"},

        "section_heading":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Section Heading"}},"machine_name":"section_heading_master","wrapper":"<div class=\"row mb-40 mb-lg-50 text-center\"><div class=\"col-lg-8 col-md-10 offset-lg-2 offset-md-1\"><h2><div class=\"field field--name-field-block-header-title field--type-text field--label-hidden field--item\">[CONTENT]</div></h2></div></div>"},
    },"element_type":"single","label":"Section Heading","machine_name":"section_heading_master","wrapper":"[CONTENT]"},

    "text_slider":{"elements":{
        0:{"properties":{"html":{"value":"","type":"single","widget":"image","selected":"","label":"Card Image"}},"machine_name":"card_image","wrapper":"<div class=\"platforms-box-image\"><img src='[CONTENT]'></div>"},
        1:{"properties":{"html":{"value":"","type":"single","widget":"image","selected":"","label":"Logo Image"}},"machine_name":"logo_image","wrapper":"<div class=\"section-5-logo\"><div class=\"platforms-box-logo\"><img src='[CONTENT]'></div></div>"},
        3:{"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Card Body","machine_name":"card_body"}},"label":"Card Body","machine_name":"card_body","wrapper":"<div class=\"section-5-content\">[CONTENT]"},
        4:{"properties":{"val":{"value":"Program Packages","type":"single","widget":"text","selected":"","label":"Text","machine_name":"button_text"},
            "href":{"value":"","type":"single","widget":"text","selected":"","label":"Link"}
          },"label":"Card Button","machine_name":"card_button","wrapper":"<div class=\"row mt-20\"><div class=\"col-12 text-center\"><a class=\"btn btn-secondary btn-lg\" href=\"[LINK]\">[CONTENT]</a></div></div></div>"}
    },"element_type":"multiple","label":"Card","machine_name":"card_master","wrapper":"<li class=\"col-lg-4 pb-20\"><div class=\"views-field views-field-nothing-1\"><span class=\"field-content\"><div class=\"platforms-box\" href=\"#\">[CONTENT]</div></span></div></li>"},
    },
    "internal_properties":{"type":"section1","html":""}};
