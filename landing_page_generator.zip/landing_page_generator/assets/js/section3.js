const section3 = {"show_properties":{
    "background":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"select","selected":"","label":"Background","option":{"background-gradient-purple":"Purple","background-gradient-light-blue":"Light Blue","background-gradient-dark-blue":"Dark Blue","background-black":"Black","background-dark-brown":"Dark Brown","background-light":"Light","background-white":"White"}}},"machine_name":"background_master","wrapper":"none"},
      },"element_type":"single","label":"Background","machine_name":"background_master","wrapper":"none"},

    "section_heading":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Section Heading"}},"machine_name":"section_heading","wrapper":"none"},
    },"element_type":"single","label":"Section Heading","machine_name":"section_heading","wrapper":"none"},
    "button":{"elements":{
        0:{"properties":{"val":{"value":"Program Packages","type":"single","widget":"text","selected":"","label":"Text","machine_name":"button_text"},
            "href":{"value":"","type":"single","widget":"text","selected":"","label":"Link"}
          },"label":"Button","machine_name":"button","wrapper":"<a class=\"btn btn-secondary\" href=\"[LINK]\">[CONTENT]</a>"},"machine_name":"button","wrapper":"none"
      },"element_type":"single","label":"Button","machine_name":"button_master","wrapper":"none"},

    "points":{"elements":{
        0: {"properties":{"html":{"value":"","type":"single","widget":"image","selected":"","label":"Point Image"}},"machine_name":"point_image","wrapper":"<img class=\"mb-20 mb-md-30 mb-lg-45\" src='[CONTENT]' width='50'/>"},
        1:{"properties":{"text" : {"value":"","type":"single","widget":"text","selected":"","label":"Sort Heading","machine_name":"point_heading"}},"label":"Sort Heading","machine_name":"point_heading","wrapper":"<h2>[CONTENT]</h2>"},
        2:{"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Point Body","machine_name":"point_body"}},"label":"Point Body","machine_name":"point_body","wrapper":"<p class=\"small\">[CONTENT]</p>"}
      },"element_type":"multiple","label":"Image With Points","machine_name":"points_master","wrapper":"<div class=\"col-md-4 pr-lg-60 padding-large-top\">[CONTENT]</div>"},

  },
    "internal_properties":{"type":"section1","html":""}};
