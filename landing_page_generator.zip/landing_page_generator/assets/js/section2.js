const section2 = {"show_properties":{
    "background":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"select","selected":"","label":"Background","option":{"background-gradient-purple":"Purple","background-gradient-light-blue":"Light Blue","background-gradient-dark-blue":"Dark Blue","background-black":"Black","background-dark-brown":"Dark Brown","background-light":"Light","background-white":"White"}}},"machine_name":"background_master","wrapper":"none"},
      },"element_type":"single","label":"Background","machine_name":"background_master","wrapper":"none"},

    "section_heading":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Section Heading"}},"machine_name":"section_heading","wrapper":"none"},
    },"element_type":"single","label":"Section Heading","machine_name":"section_heading","wrapper":"none"},

    "sub_section_heading_1":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Sub Section Heading 1"}},"machine_name":"sub_section_heading_1","wrapper":"none"},
      },"element_type":"single","label":"Sub Section Heading 1","machine_name":"sub_section_heading_1","wrapper":"none"},

    "sub_section_heading_2":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Sub Section Heading 2"}},"machine_name":"sub_section_heading_2","wrapper":"none"},
      },"element_type":"single","label":"Sub Section Heading 2","machine_name":"sub_section_heading_2","wrapper":"none"},

    "sub_body_1":{"elements": {
       0: {"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Sub Body 1"}},"machine_name":"sub_body_1","wrapper":"none"}
    },"element_type":"single","label": "Sub Body 1","machine_name":"sub_body_1","wrapper":"none"},

    "sub_body_2":{"elements": {
        0: {"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Sub Body 2"}},"machine_name":"sub_body_2","wrapper":"none"}
      },"element_type":"single","label": "Sub Body 2","machine_name":"sub_body_2","wrapper":"none"},

    "sub_body_3":{"elements": {
        0: {"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Sub Body 3"}},"machine_name":"sub_body_3","wrapper":"none"}
      },"element_type":"single","label": "Sub Body 3","machine_name":"sub_body_3","wrapper":"none"},

    "sub_body_4":{"elements": {
        0: {"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Sub Body 4"}},"machine_name":"sub_body_4","wrapper":"none"}
      },"element_type":"single","label": "Sub Body 4","machine_name":"sub_body_4","wrapper":"none"},

    "image":{"elements": {
        0: {"properties":{"html":{"value":"","type":"single","widget":"image","selected":"","label":"Image"}},"machine_name":"image","wrapper":"none"}
      },"element_type":"single","label": "Image","machine_name":"image","wrapper":"none"},
    "image_buttom_body":{"elements": {
        0: {"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Image Buttom Text"}},"machine_name":"image_buttom_body","wrapper":"none"}
      },"element_type":"single","label": "Image Buttom Text","machine_name":"image_buttom_body","wrapper":"none"},

  },
    "internal_properties":{"type":"section1","html":""}};
