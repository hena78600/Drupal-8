const section6 = {"show_properties":{
    "background":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"select","selected":"","label":"Background","option":{"background-gradient-purple":"Purple","background-gradient-light-blue":"Light Blue","background-gradient-dark-blue":"Dark Blue","background-black":"Black","background-dark-brown":"Dark Brown","background-light":"Light","background-white":"White"}}},"machine_name":"background_master","wrapper":"none"},
      },"element_type":"single","label":"Background","machine_name":"background_master","wrapper":"none"},

    "heading":{"elements":{
                0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Heading"}},"machine_name":"heading","wrapper":"none"},
            },"element_type":"single","label":"Heading","machine_name":"heading_master","wrapper":"none"},
        "body":{"elements": {
                0: {"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Body"}},"machine_name":"body","wrapper":"none"}
            },"element_type":"single","label": "Body","machine_name":"body_master","wrapper":"none"},
        "right_image":{"elements": {
                0: {"properties":{"html":{"value":"","type":"single","widget":"image","selected":"","label":"Video"},
                  "poster":{"value":"","type":"single","widget":"text","selected":"","label":"Poster Image"}},"machine_name":"right_image","wrapper":"<video controls=\"\" poster=\"[POSTER]\" class=\"mb-40\"><source src=\"[CONTENT]\" type=\"video/mp4\">Your browser does not support HTML5 video.</video>"}
            },"element_type":"single","label": "Image","machine_name":"right_image","wrapper":"[CONTENT]"},
    },
    "internal_properties":{"type":"section1","html":""}};
