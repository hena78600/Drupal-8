const section23 = {"show_properties":{
        "background":{"elements":{
                0:{"properties":{"text":{"value":"Testing","type":"single","widget":"select","selected":"","label":"Background","option":{"background-gradient-purple":"Purple","background-gradient-light-blue":"Light Blue","background-gradient-dark-blue":"Dark Blue","background-black":"Black","background-dark-brown":"Dark Brown","background-light":"Light","background-white":"White"}}},"machine_name":"background_master","wrapper":"none"},
            },"element_type":"single","label":"Background","machine_name":"background_master","wrapper":"none"},

        "section_heading":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Section Heading"}},"machine_name":"section_heading_master","wrapper":"<h2 class=\"mb-20\">[CONTENT]</h2>"},
    },"element_type":"single","label":"Section Heading","machine_name":"section_heading_master","wrapper":"[CONTENT]"},

    "text_slider":{"elements":{
        0:{"properties":{"html":{"value":"","type":"single","widget":"image","selected":"","label":"Logo Image"}},"machine_name":"logo_image","wrapper":"<img src=\"[CONTENT]\" alt=\"build-stage\"/>"},
        1:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Card Heading"}},"machine_name":"card_heading","wrapper":"<p><span>[CONTENT]</span><br>"},
        2:{"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Card Body","machine_name":"card_body"}},"label":"Card Body","machine_name":"card_body","wrapper":"[CONTENT]</p>"},
    },"element_type":"multiple","label":"Card","machine_name":"card_master","wrapper":"<div class=\"col-md-3\"><div class=\"four-stages mb-30\">[CONTENT]</div></div>"},
    },
    "internal_properties":{"type":"section1","html":""}};
