const slider = {"show_properties":{
    "text_slider":{"elements":{
            0:{"properties":{"html":{"value":"","type":"single","widget":"image","selected":"","label":"Banner Image"}},"machine_name":"banner_image","wrapper":"<img class=\"d-block w-100\" src=\"[CONTENT]\" alt=\"First slide\"><div class=\"carousel-caption d-md-block bannertopcontent\">"},
            1:{"properties":{"html":{"value":"","type":"single","widget":"image","selected":"","label":"Logo Image"}},"machine_name":"logo_image","wrapper":"<img src=\"[CONTENT]\" class=\"center-block\" /><div class=\"mb-30 visible-lg visible-md\"></div><div class=\"mb-10 visible-sm visible-xs\"></div>"},
            2:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Heading"}},"machine_name":"heading","wrapper":" <h1 class=\"text-center\"><div class=\"field field--name-field-banner-title field--type-text field--label-hidden field--item\">[CONTENT]</div></h1><div class=\"mb-20 visible-xs visible-sm\"></div>"},
            3:{"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Card Body","machine_name":"card_body"}},"label":"Card Body","machine_name":"card_body","wrapper":"<div class=\"field field--name-body field--type-text-with-summary field--label-hidden field--item mb-40 hidden-xs hidden-sm\"><p class=\"text-center\">[CONTENT]</p></div>"},
        4:{"properties":{"val":{"value":"Program Packages","type":"single","widget":"text","selected":"","label":"Text","machine_name":"button_text"},
            "href":{"value":"","type":"single","widget":"text","selected":"","label":"Link"}
          },"label":"Button","machine_name":"button","wrapper":"<div class=\"text-center\"><a class=\"btn btn-secondary btn-lg\" href=\"[LINK]\">[CONTENT]</a></div></div>"},

      },"element_type":"multiple","label":"Card","machine_name":"card_master","wrapper":"<div class=\"item homebanner active\">[CONTENT]</div>"},
    },
    "internal_properties":{"type":"section1","html":""}};
