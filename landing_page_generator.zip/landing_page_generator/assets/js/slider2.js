const slider2 = {"show_properties":{
    "section_heading":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Section Heading"}},"machine_name":"section_heading_master","wrapper":"none"},
    },"element_type":"single","label":"Section Heading","machine_name":"section_heading_master","wrapper":"none"},

    "text_slider":{"elements":{
        0:{"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Card Body","machine_name":"card_body"}},"label":"Card Body","machine_name":"card_body","wrapper":"<div class=\"col-lg-6\"><div class=\"landingpage-promotion-box-large-content\"><p>[CONTENT]</p>"},
        1:{"properties":{"val":{"value":"Program Packages","type":"single","widget":"text","selected":"","label":"Text","machine_name":"button_text"},
            "href":{"value":"","type":"single","widget":"text","selected":"","label":"Link"}
          },"label":"Button","machine_name":"button","wrapper":"<span class=\"btn btn-secondary-arrow\" ><a href='[LINK]' >[CONTENT]</a></span></div></div>"},
        2:{"properties":{"html":{"value":"","type":"single","widget":"image","selected":"","label":"Logo Image"}},"machine_name":"logo_image","wrapper":"<div class=\"col-lg-6 landingpage-promotion-box-large-image\" style=\"background-image: url('[CONTENT]')\"></div>"},

      },"element_type":"multiple","label":"Card","machine_name":"card_master","wrapper":"<div class=\"carousel-cell\"><div class=\"row\"><div class=\"col-lg-10 offset-lg-1\"><div class=\"landingpage-promotion-box-large\"><div class=\"row no-gutters\">[CONTENT]</div></div></div></div></div>"},
    },
    "internal_properties":{"type":"section1","html":""}};
