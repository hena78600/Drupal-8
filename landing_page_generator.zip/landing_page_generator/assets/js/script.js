$(document).ready(function(){
	$(document).ready(function(){
});
	
});

var section_id = 1;
var section_selection_id = "";
var sub_section_id = 1;
var sub_section_selection_id = "";
var select_element_id = "";
var select_elements_object = {};
var button_id = 1;
var paragraph_id = 1;
var previous_class = "";
var menu_id = 1;
function add_section() {
    if(select_element_id != "") {
        section_id = section_id + 1;
        var section = "<div class='section clearfix' id='section-" + section_id + "'></div>";
        $("#" + select_element_id).append(section);
    }
    else {
        alert("Please select a section!");
    }
}

/*function section_select(section_element) {
    section_selection_id =  section_element.id;
    console.log(section_selection_id)
}*/

function add_sub_section() {
    sub_section_id = sub_section_id + 1;
    var sub_section = "<div class='sub-section' id='sub-section-"+sub_section_id+"'></div>";
    if(select_element_id != "") {
        $("#"+select_element_id).append(sub_section);
    }
    else {
        alert("Please select a section!");
    }
}

/*
function sub_section_select(sub_section_element) {
   /!* sub_section_selection_id = sub_section_element.id;
    console.log(sub_section_selection_id);*!/
}*/

function add_element(type) {
    switch(type) {
        case "button":
            button_id = button_id + 1;
            var element_id = "button-"+button_id;
            var element_html = button.internal_properties.html;
            element_html = element_html.replace("[ID]","button-"+button_id);
            var local_button = JSON.parse(JSON.stringify(button));
            $("#" + select_element_id).append(element_html);
            select_elements_object[element_id] = local_button;
            select_elements_object[element_id].show_properties.id = element_id;
            console.log(select_elements_object);
            break;
        case "section" :
            section_id = section_id + 1;
            var element_html = section.internal_properties.html;
            var element_id = "section-"+section_id;
            var local_section = JSON.parse(JSON.stringify(section));
            element_html = element_html.replace("[ID]","section-"+section_id);
            $("#"+select_element_id).append(element_html);
            select_elements_object[element_id] = local_section;
            select_elements_object[element_id].internal_properties.html = element_html;
            console.log(select_elements_object);
            break;
        case "sub_section" :
            sub_section_id = sub_section_id + 1;
            var element_html = sub_section.internal_properties.html;
            var element_id = "sub-section-"+sub_section_id;
            var local_sub_section = JSON.parse(JSON.stringify(sub_section));
            element_html = element_html.replace("[ID]","sub-section-"+sub_section_id);
            element_html = element_html.replace("[INDEX]",sub_section_id);
            $("#"+select_element_id).append(element_html);
            select_elements_object[element_id] = local_sub_section;
            select_elements_object[element_id].internal_properties.html = element_html;
            console.log(select_elements_object);
            break;
        case "paragraph" :
            paragraph_id = paragraph_id + 1;
            var element_html = paragraph.internal_properties.html;
            var element_id = "paragraph-"+paragraph_id;
            var local_sub_section = JSON.parse(JSON.stringify(paragraph));
            element_html = element_html.replace("[ID]","paragraph-"+paragraph_id);
            element_html = element_html.replace("[INDEX]",paragraph_id);
            $("#"+select_element_id).append(element_html);
            select_elements_object[element_id] = local_sub_section;
            select_elements_object[element_id].internal_properties.html = element_html;
            console.log(select_elements_object);
            break;
        case "menu" :
            menu_id = menu_id + 1;
            var element_html = menu.internal_properties.html;
            var element_id = "menu-"+menu_id;
            var local_sub_section = JSON.parse(JSON.stringify(menu));
            element_html = element_html.replace("[ID]","menu-"+menu_id);
            element_html = element_html.replace("[INDEX]",menu_id);
            $("#"+select_element_id).append(element_html);
            select_elements_object[element_id] = local_sub_section;
            select_elements_object[element_id].internal_properties.html = element_html;
            /*var items = select_elements_object[select_element_id].show_properties.items.value;
            var item_str = "";
            for(item in items) {
                item_str += "<li>"+items[item].text+"</li>";
            }
            $("#"+select_element_id+" > ul").html(item_str);*/
            console.log(select_elements_object);
            break;
    }
}

function apply_properties(object) {
    //alert($(object).val());
    var name  = object.name;
    var value = $(object).val();
    if(value === undefined) {
        value = $(object).text();
    }
    var properties_name = $(object).data("properties-name");
    var str = "$('#"+select_element_id+"')."+properties_name+"('"+value+"')";
    str = str.replace(/(\r\n|\n|\r)/gm, "");
    var command = eval(str);
    //document.write(command);
    select_elements_object[select_element_id].show_properties[properties_name]['value'] = value;
}

function remove_element() {
    if(select_element_id != "right") {
        $("#"+select_element_id).remove();
        delete select_elements_object[select_element_id];
        $("#element-properties").html("");
        select_element_id = "right";
    }
}

function get_previous_class(object) {
    previous_class = object.value;
}

function change_class(object) {
    if(previous_class != "none") {
        $("#"+select_element_id).removeClass(previous_class);
    }
    var properties_name = $(object).data("properties-name");
    $("#"+select_element_id).addClass(object.value);
    //$("#"+select_element_id).click();
    select_elements_object[select_element_id]['show_properties'][properties_name]['selected'] = object.value;
    console.log(select_elements_object[select_element_id]);
    $("#"+select_element_id).focus();
}

function add_menu_item() {
    var update_status =  $("#menu-item-update").val();
    var item_name = $("#add-item-text").val();
    var item_link = $("#add-item-link").val();
    if(update_status == 0) {
        $("#" + select_element_id + " > ul").append("<li><a href='" + item_link + "'>" + item_name + "</a></li>");
        //$("#add-item-text").val('');
        $("#add-item-text").val("");
        $("#add-item-link").val("");
        var items = select_elements_object[select_element_id].show_properties.items.value;
        var item_count = 0;
        for (item in items) {
            item_count = parseInt(item);
        }
        item_count = item_count + 1;
        var new_item_object = {};
        Object.assign(new_item_object, item_count);
        new_item_object[item_count] = {};
        new_item_object[item_count] = {"text": item_name, "link": item_link};
        Object.assign(select_elements_object[select_element_id].show_properties.items.value, new_item_object);
        /*select_elements_object[select_element_id].show_properties.items.value.assign();*/
        //select_elements_object[select_element_id].show_properties.items.value[item_count] = new_item_object;
        $("#show-menu-items").append("<div id='item-" + item_count + "'><label>" + item_name + "</label><input type='button' value='Remove' onclick='remove_item(" + item_count + ")'> <input type='button' value='edit' onclick='edit_item(" + item_count + ")'></div>");
    }
    else {
        var item_number =  $("#menu-item-update").data('item-id');
        select_elements_object[select_element_id].show_properties.items.value[item_number].text = item_name;
        select_elements_object[select_element_id].show_properties.items.value[item_number].link = item_link;
        $("#item-"+item_number).html("<label>" + item_name + "</label><input type='button' value='Remove' onclick='remove_item(" + item_number + ")'> <input type='button' value='edit' onclick='edit_item(" + item_number + ")'>");
        var items = select_elements_object[select_element_id].show_properties.items.value;
        var item_str = "";
        for(item in items) {
            item_str += "<li><a href='"+items[item].link+"'>"+items[item].text+"</a></li>";
        }
        $("#"+select_element_id+" > ul").html(item_str);
        $("#menu-item-update").val(0);
        $("#menu-item-update").data('item-id',0);
        $("#add-item").val("Add");
        $("#add-item-text").val("");
        $("#add-item-link").val("");
    }
    console.log(select_elements_object[select_element_id]);

}

function remove_item(item_number) {
    delete select_elements_object[select_element_id].show_properties.items.value[item_number];
    $("#item-"+item_number).remove();
    var items = select_elements_object[select_element_id].show_properties.items.value;
    var item_str = "";
    for(item in items) {
        item_str += "<li><a href='"+items[item].link+"'>"+items[item].text+"</a></li>";
    }
    $("#"+select_element_id+" > ul").html(item_str);


}

function edit_item(item_number) {
    var item = select_elements_object[select_element_id].show_properties.items.value[item_number];
    $("#add-item-text").val(item.text);
    $("#add-item-link").val(item.link);
    $("#menu-item-update").val(1);
    $("#menu-item-update").data('item-id',item_number);
    $("#add-item").val("Update");
}

function show_add_popup(element_name) {
    var class_name = element_name;
    var popup_html="<div class='container'>";
    $("#add-popup").show();
    var local_object = JSON.parse(JSON.stringify(eval(class_name)));
    for(index in local_object.show_properties) {
        propertie = local_object.show_properties[index]['elements'];
        if(local_object.show_properties[index]["element_type"] == "multiple") {
            popup_html += "<div id='"+local_object.show_properties[index]["machine_name"]+"'>";
            popup_html += "<h1>"+local_object.show_properties[index]['label']+"<span onclick=\"add_more_elements('"+class_name+"','"+local_object.show_properties[index]["machine_name"]+"')\">+</span></h1>";
            popup_html += "<div class='"+local_object.show_properties[index]["machine_name"]+"'>";
            var loop_index = 1;
            for (index2 in propertie) {
                for (index3 in propertie[index2]['properties']) {
                    popup_html += "<div class='row'><div class='col-md-2'>" + propertie[index2]['properties'][index3]['label'] + "</div>";
                    if (propertie[index2]['properties'][index3]['widget'] == "text") {
                        popup_html += "<div class='col-md-8'><input type='text' id='"+propertie[index2]['machine_name']+"-"+index3+"-"+loop_index+"'></div>";
                    }
                    else if (propertie[index2]['properties'][index3]['widget'] == "textarea") {
                        popup_html += "<div class='col-md-8'><textarea id='"+propertie[index2]['machine_name']+"-"+index3+"-"+loop_index+"'></textarea><script></script></div>";
                    }
                    popup_html += "</div>";
                }
            }
            popup_html += "</div>";
            popup_html += "</div>";
        }
        else {
            popup_html += "<div id='"+local_object.show_properties[index]["machine_name"]+"'>";
            popup_html += "<h1>"+local_object.show_properties[index]['label']+"</h1>";
            for (index2 in propertie) {
                for (index3 in propertie[index2]['properties']) {
                    popup_html += "<div class='row'><div class='col-md-2'>" + propertie[index2]['properties'][index3]['label'] + "</div>";
                    if (propertie[index2]['properties'][index3]['widget'] == "text") {
                        popup_html += "<div class='col-md-8'><input type='text' id='"+propertie[index2]['machine_name']+"-"+index3+"'></div>";
                    }
                    else if (propertie[index2]['properties'][index3]['widget'] == "textarea") {
                        popup_html += "<div class='col-md-8'><textarea id='"+propertie[index2]['machine_name']+"-"+index3+"'></textarea><script></script></div>";
                    }
                    popup_html += "</div>";

                }
            }
            popup_html += "</div>";
        }
    }
    popup_html += "<div class='row pb-20'><input type='button' name='create' value='Create' onclick=\"create_element('"+class_name+"')\"></div>";
    popup_html += "</div>";
    $("#add-popup").html(popup_html);

}

function calculate_next_id(element_type) {
    var next_id = 1;
    for (index in select_elements_object) {
        var object = select_elements_object[index];
        if(object.internal_properties.type == element_type) {
            next_id = next_id + 1;
        }
    }
    if(next_id > 1) {
        next_id = next_id + 1;
    }
    return next_id;
}

function add_more_elements(class_name,element_machine_name) {
    //alert(element_machine_name);
    var object = eval(class_name);
    var html = "";
    var next_id = 0;
    $("."+element_machine_name).each(function() {
        next_id = next_id + 1;
    });
    next_id++;
    html += "<div class='"+element_machine_name+"'>";
    for (index in object.show_properties) {
        if(object.show_properties[index]['machine_name'] == element_machine_name) {
            for (index2 in object.show_properties[index]['elements']) {
                for (index3 in object.show_properties[index]['elements'][index2]['properties']) {
                    html += "<div class='row'><div class='col-md-2'>" + object.show_properties[index]['elements'][index2]['properties'][index3]['label'] + "</div>";
                    if (object.show_properties[index]['elements'][index2]['properties'][index3]['widget'] == "text") {
                        html += "<div class='col-md-8'><input type='text' id='"+object.show_properties[index]['elements'][index2]['machine_name']+"-"+index3+"-"+next_id+"'></div>";
                    }
                    else if (object.show_properties[index]['elements'][index2]['properties'][index3]['widget'] == "textarea") {
                        html += "<div class='col-md-8'><textarea id='"+object.show_properties[index]['elements'][index2]['machine_name']+"-"+index3+"-"+next_id+"'></textarea><script></script></div>";
                    }
                    html += "</div>";
                }
            }
        }
    }
    html += "</div>";
    $("#"+element_machine_name).append(html);
    var a =0;
}

function create_element(element_class_name) {
    var object = eval(element_class_name);
    $.get("templates/"+element_class_name+".html",function (content) {
        for (index in object['show_properties']) {
            var machine_name = object['show_properties'][index]['machine_name'];
            if(object['show_properties'][index]['wrapper'] == "none") {
                for (index2 in object['show_properties'][index]['elements']) {
                    if(object['show_properties'][index]['elements'][index2]['wrapper'] == "none") {
                        for (index3 in object['show_properties'][index]['elements'][index2]['properties']) {
                            if (object['show_properties'][index]['element_type'] == "single") {
                                var properties_machine_name = object['show_properties'][index]['elements'][index2]['machine_name'];
                                var replace_content = $("#" + properties_machine_name + "-" + index3).val();
                                content = content.replace("[" + machine_name + "]", replace_content);
                            }
                            else if (object['show_properties'][index]['element_type'] == "multiple") {

                            }
                        }
                    }
                    else {
                        var child_wrapper = "";
                        child_wrapper += object['show_properties'][index]['elements'][index2]['wrapper'];
                        for(index3 in object['show_properties'][index]['elements'][index2]['properties']) {
                            var properties_machine_name = object['show_properties'][index]['elements'][index2]['machine_name'];
                            var replace_content = $("#" + properties_machine_name+"-"+index3).val();
                            if(index3 == 'href') {
                                child_wrapper = child_wrapper.replace('[LINK]', replace_content);

                            }
                            else {
                                child_wrapper = child_wrapper.replace('[CONTENT]', replace_content);
                            }
                        }
                        content = content.replace("["+machine_name+"]",child_wrapper);
                    }
                }
            }
            else {
                var master_wrapper = "";
                var child_wrapper = "";
                if (object['show_properties'][index]['element_type'] == "single") {
                    master_wrapper += object['show_properties'][index]['wrapper'];
                    for (index2 in object['show_properties'][index]['elements']) {
                        child_wrapper += object['show_properties'][index]['elements'][index2]['wrapper'];
                        for(index3 in object['show_properties'][index]['elements'][index2]['properties']) {
                            var properties_machine_name = object['show_properties'][index]['elements'][index2]['machine_name'];
                            var replace_content = $("#" + properties_machine_name+"-"+index3).val();
                            if(index3 == 'href') {
                                child_wrapper = child_wrapper.replace('[LINK]', replace_content);

                            }
                            else {
                                child_wrapper = child_wrapper.replace('[CONTENT]', replace_content);
                            }
                        }
                        //content += content.replace("["+machine_name+"]",replace_content);
                    }
                    if(object['show_properties'][index]['wrapper'] != "none") {
                        alert(child_wrapper);
                        master_wrapper = master_wrapper.replace('[CONTENT]', child_wrapper);
                    }
                    else {
                        master_wrapper += child_wrapper;
                    }
                }
                else if (object['show_properties'][index]['element_type'] == "multiple") {
                    //var properties_machine_name = object['show_properties'][index]['elements'][index2]['machine_name'];
                    var element_count = 1;
                    $("."+machine_name).each(function () {
                        master_wrapper += object['show_properties'][index]['wrapper'];
                        for(index2 in object['show_properties'][index]['elements']) {
                            var properties_machine_name = object['show_properties'][index]['elements'][index2]['machine_name'];
                            for(index3 in object['show_properties'][index]['elements'][index2]['properties']) {
                                child_wrapper += object['show_properties'][index]['elements'][index2]['wrapper'];
                                var replace_content = $("#" + properties_machine_name + "-"+index3+"-" + element_count).val();
                                if(index3 == 'href') {
                                    child_wrapper = child_wrapper.replace('[LINK]', replace_content);

                                }
                                else {
                                    child_wrapper = child_wrapper.replace('[CONTENT]', replace_content);
                                }
                            }
                        }
                        master_wrapper = master_wrapper.replace('[CONTENT]',child_wrapper);
                        child_wrapper = "";
                        element_count++;
                    });
                }
                console.log("testing");
                content = content.replace("["+machine_name+"]",master_wrapper);
            }
        }
        $("#right").append(content);
        $("#add-popup").hide();
    },'html');

}