const section18 = {"show_properties":{
        "background":{"elements":{
                0:{"properties":{"text":{"value":"Testing","type":"single","widget":"select","selected":"","label":"Background","option":{"background-gradient-purple":"Purple","background-gradient-light-blue":"Light Blue","background-gradient-dark-blue":"Dark Blue","background-black":"Black","background-dark-brown":"Dark Brown","background-light":"Light","background-white":"White"}}},"machine_name":"background_master","wrapper":"none"},
            },"element_type":"single","label":"Background","machine_name":"background_master","wrapper":"none"},

        "section_heading":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Section Heading"}},"machine_name":"section_heading_master","wrapper":"none"},
    },"element_type":"single","label":"Section Heading","machine_name":"section_heading_master","wrapper":"none"},

    "item_master":{"elements":{
        0:{"properties":{"html":{"value":"","type":"single","widget":"image","selected":"","label":"Item Image"}},"machine_name":"item_image","wrapper":"<img class=\"img-responsive fac_imgs\" src='[CONTENT]'>"},
        1:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Item Heading"}},"machine_name":"item_heading","wrapper":"<p>[CONTENT]</p>"},
    },"element_type":"multiple","label":"Item","machine_name":"item_master","wrapper":"<div class=\"col-lg-4 col-md-6\">[CONTENT]</div>"},
    },
    "internal_properties":{"type":"section1","html":""}};
