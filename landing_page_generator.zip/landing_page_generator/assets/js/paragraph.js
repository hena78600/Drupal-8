//var button = {"type": "button","html": "<input type='button' value='Test1' data-type='button' id='test1' />","value": "Test1","id": ""};
var paragraph = {"show_properties":{
    "html": {"value":"Paragraph","type":"single","widget":"textarea","selected":"","label":"Value"},
    "id": {"value":"","type":"single","widget":"textbox","selected":"","label":"Id"},
    "text_type":{"value":{"none":"none","bold":"bold"},"type":"multi","widget":"select","label":"Text Type"}},"internal_properties":{"type": "paragraph","html": "<p id='[ID]'>Paragraph<p/>",}};