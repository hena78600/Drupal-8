const section = {"show_properties":{
        "width":{"value":"100%","type":"single","selected":"","widget":"textbox","label":"Width"},
        "min-hieght":{"value":"100px","type":"single","selected":"","widget":"textbox","label":"Min Height"}},
    "internal_properties":{"type":"section","html":"<div class='section clearfix' data-type='section' id='[ID]'></div>"}};
Object.freeze(section);