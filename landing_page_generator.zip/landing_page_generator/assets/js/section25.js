const section25 = {"show_properties":{
    "background":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"select","selected":"","label":"Background","option":{"background-gradient-purple":"Purple","background-gradient-light-blue":"Light Blue","background-gradient-dark-blue":"Dark Blue","background-black":"Black","background-dark-brown":"Dark Brown","background-light":"Light","background-white":"White"}}},"machine_name":"background_master","wrapper":"none"},
      },"element_type":"single","label":"Background","machine_name":"background_master","wrapper":"none"},

    "section_heading":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Section Heading"}},"machine_name":"section_heading_master","wrapper":"<h2>[CONTENT]</h2>"},
    },"element_type":"single","label":"Section Heading","machine_name":"section_heading_master","wrapper":"<div class=\"row padding-large-bottom text-center\"><div class=\"col-lg-8 col-md-10 offset-lg-2 offset-md-1\">[CONTENT]</div></div>"},

    "card":{"elements":{
            0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Card Sub Title"}},"machine_name":"card_sub_title","wrapper":"<div class=\"landing-box-details\"><span>[CONTENT]</span></div>"},
            1:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Card Title"}},"machine_name":"card_title","wrapper":"<div class=\"landing-box-content\"><h4>[CONTENT]</h4></div>"},
            2: {"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Card Body"}},"machine_name":"card_body","wrapper":"<div class=\"landing-box-content\"><p>[CONTENT]</p></div>"},
            3:{"properties":{"val":{"value":"Program Packages","type":"single","widget":"text","selected":"","label":"Text","machine_name":"button_text"},
            "href":{"value":"","type":"single","widget":"text","selected":"","label":"Link"}
          },"label":"Card Button","machine_name":"card_button","wrapper":"<a class=\"btn btn-secondary btn-sm\" href=\"[LINK]\">[CONTENT]</a>"}
    },"element_type":"multiple","label":"Card","machine_name":"card_master","wrapper":"<div class=\"col-lg-6\"><div class=\"landing-box\">[CONTENT]</div></span></div></li>"},
    },
    "internal_properties":{"type":"section1","html":""}};
