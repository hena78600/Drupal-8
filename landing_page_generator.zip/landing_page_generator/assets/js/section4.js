const section4 = {"show_properties":{
        "background":{"elements":{
                0:{"properties":{"text":{"value":"Testing","type":"single","widget":"select","selected":"","label":"Background","option":{"background-gradient-purple":"Purple","background-gradient-light-blue":"Light Blue","background-gradient-dark-blue":"Dark Blue","background-black":"Black","background-dark-brown":"Dark Brown","background-light":"Light","background-white":"White"}}},"machine_name":"background_master","wrapper":"none"},
            },"element_type":"single","label":"Background","machine_name":"background_master","wrapper":"none"},

        "section_heading":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Section Heading"}},"machine_name":"section_heading_master","wrapper":"none"},
    },"element_type":"single","label":"Section Heading","machine_name":"section_heading_master","wrapper":"none"},
    "section_body":{"elements": {
       0: {"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Body"}},"machine_name":"section_body","wrapper":"none"}
    },"element_type":"single","label": "Section Body","machine_name":"section_body_master","wrapper":"none"},
    "text_slider":{"elements":{
        0:{"properties":{"text" : {"value":"","type":"single","widget":"text","selected":"","label":"Slider Heading","machine_name":"slider_heading"}},"label":"Slider Heading","machine_name":"slider_heading","wrapper":"<h4>[CONTENT]</h4>"},
        1:{"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Section Body","machine_name":"section_body"}},"label":"Section Body","machine_name":"section_body","wrapper":"<p>[CONTENT]</p>"},
        2:{"properties":{"val":{"value":"Program Packages","type":"single","widget":"text","selected":"","label":"Text","machine_name":"button_text"},
            "href":{"value":"","type":"single","widget":"text","selected":"","label":"Link"}
          },"label":"Button","machine_name":"button","wrapper":"<a class=\"btn btn-primary-arrow\" href=\"[LINK]\">[CONTENT]</a>"}
    },"element_type":"multiple","label":"Slider","machine_name":"slider_master","wrapper":"<div class=\"carousel-cell\"><div class='row'><div class=\"col-8 offset-2 col-md-8 offset-md-2 col-lg-6 offset-lg-3 text-center event-blocks\">[CONTENT]</div></div></div>"},
    },
    "internal_properties":{"type":"section1","html":""}};
