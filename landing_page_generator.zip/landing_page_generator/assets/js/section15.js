const section15 = {"show_properties":{
    "background":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"select","selected":"","label":"Background","option":{"background-gradient-purple":"Purple","background-gradient-light-blue":"Light Blue","background-gradient-dark-blue":"Dark Blue","background-black":"Black","background-dark-brown":"Dark Brown","background-light":"Light","background-white":"White"}}},"machine_name":"background_master","wrapper":"none"},
      },"element_type":"single","label":"Background","machine_name":"background_master","wrapper":"none"},

    "section_heading":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Section Heading"}},"machine_name":"section_heading_master","wrapper":"none"},
    },"element_type":"single","label":"Section Heading","machine_name":"section_heading_master","wrapper":"none"},

    "text_slider":{"elements":{
        0:{"properties":{"html":{"value":"","type":"single","widget":"image","selected":"","label":"Logo Image"}},"machine_name":"logo_image","wrapper":"<div class=\"technology-box-logo\"><img src='[CONTENT]'></div>"},
        1:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Card Heading"}},"machine_name":"card_heading","wrapper":"<h3 class=\"technology_header\">[CONTENT]</h3>"},
        2:{"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Card Body","machine_name":"card_body"}},"label":"Card Body","machine_name":"card_body","wrapper":"<p>[CONTENT]</p>"},
    },"element_type":"multiple","label":"Card","machine_name":"card_master","wrapper":"<div class=\"techBox col-xl-3 col-lg-4 col-md-6 techBox moreBox\"><div class=\"views-field views-field-nothing\"><span class=\"field-content\"><div class=\"technology-box\"><div class=\"technology-box-content\">[CONTENT]</div></div></span></div></div>"},
    "button":{"elements":{
                0:{"properties":{"val":{"value":"Program Packages","type":"single","widget":"text","selected":"","label":"Text","machine_name":"button_text"},
                        "href":{"value":"","type":"single","widget":"text","selected":"","label":"Link"}
                    },"label":"Button","machine_name":"button","wrapper":"<a href='#' class=\"btn btn-secondary btn-lg\" id=\"loadMore\"> [CONTENT] </a>"},"machine_name":"button","wrapper":"none"
            },"element_type":"single","label":"Button","machine_name":"button_master","wrapper":"none"}
    },
    "internal_properties":{"type":"section1","html":""}};
