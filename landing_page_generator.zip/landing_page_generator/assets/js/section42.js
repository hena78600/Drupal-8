const section42 = {"show_properties":{
    "background":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"select","selected":"","label":"Background","option":{"background-gradient-purple":"Purple","background-gradient-light-blue":"Light Blue","background-gradient-dark-blue":"Dark Blue","background-black":"Black","background-dark-brown":"Dark Brown","background-light":"Light","background-white":"White"}}},"machine_name":"background_master","wrapper":"none"},
      },"element_type":"single","label":"Background","machine_name":"background_master","wrapper":"none"},

    "heading":{"elements":{
                0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Heading"}},"machine_name":"heading","wrapper":"<div class=\"field field--name-field-product-benefit-title field--type-string field--label-hidden field--item\">[CONTENT]</div>"},
            },"element_type":"single","label":"Heading","machine_name":"heading_master","wrapper":"<h4>[CONTENT]</h4>"},
        "body":{"elements": {
                0: {"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Body"}},"machine_name":"body","wrapper":"<p>[CONTENT]</p>"}
            },"element_type":"single","label": "Body","machine_name":"body_master","wrapper":"[CONTENT]"},
      "videos":{"elements":{
          0:{"properties":{"text" : {"value":"","type":"single","widget":"text","selected":"","label":"Youtube Link","machine_name":"youtube_link"}},"label":"Youtube Link","machine_name":"youtube_link","wrapper":"<iframe width=\"100%\" height=\"300\" src=\"[CONTENT]\" frameborder=\"0\" allowfullscreen></iframe>"},
        },"element_type":"single","label":"Videos","machine_name":"videos_master","wrapper":"<div class=\"landing-box-content\">[CONTENT]</div>"},
    "button":{"elements":{
        0:{"properties":{"val":{"value":"Program Packages","type":"single","widget":"text","selected":"","label":"Text","machine_name":"button_text"},
            "href":{"value":"","type":"single","widget":"text","selected":"","label":"Link"}
          },"label":"Button","machine_name":"button","wrapper":"<a class=\"btn btn-secondary btn-lg mt-20\" href=\"[LINK]\">[CONTENT]</a>"},"machine_name":"button","wrapper":"none"
      },"element_type":"single","label":"Button","machine_name":"button_master","wrapper":"none"}

  },
    "internal_properties":{"type":"section1","html":""}};
