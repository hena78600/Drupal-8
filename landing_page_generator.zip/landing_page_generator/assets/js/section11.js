const section11 = {"show_properties":{
    "heading1":{"elements":{
        0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Heading 1"}},"machine_name":"heading1","wrapper":"<h1 class=\"text-light m-0\">[CONTENT]</h1>"},
    },"element_type":"single","label":"Heading 1","machine_name":"heading_1_master","wrapper":"[CONTENT]"},
    "heading2":{"elements":{
                0:{"properties":{"text":{"value":"Testing","type":"single","widget":"text","selected":"","label":"Heading 2"}},"machine_name":"heading2","wrapper":"<h2 class=\"text-light\">[CONTENT]</h2>"},
            },"element_type":"single","label":"Heading 2","machine_name":"heading_2_master","wrapper":"[CONTENT]"},
    "body1":{"elements": {
       0: {"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Body 1"}},"machine_name":"body1","wrapper":"none"}
    },"element_type":"single","label": "Body 1","machine_name":"body_1_master","wrapper":"none"},
        "body2":{"elements": {
                0: {"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Body 2"}},"machine_name":"body2","wrapper":"none"}
            },"element_type":"single","label": "Body 1","machine_name":"body_2_master","wrapper":"none"},
        "body3":{"elements": {
                0: {"properties":{"html":{"value":"","type":"single","widget":"textarea","selected":"","label":"Body 3"}},"machine_name":"body3","wrapper":"none"}
            },"element_type":"single","label": "Body 3","machine_name":"body_3_master","wrapper":"none"},
        "button1":{"elements":{
                0:{"properties":{"val":{"value":"Program Packages","type":"single","widget":"text","selected":"","label":"Text","machine_name":"button_text_1"},
                        "href":{"value":"","type":"single","widget":"text","selected":"","label":"Link"}
                    },"label":"Button 1","machine_name":"button1","wrapper":"<a class=\"btn btn-secondary btn-md overflow-hide-txt d-block mt-30\" href=\"[LINK]\">[CONTENT]</a>"},"machine_name":"button1","wrapper":"none"
            },"element_type":"single","label":"Button 1","machine_name":"button_1_master","wrapper":"none"},

        "button2":{"elements":{
                0:{"properties":{"val":{"value":"Program Packages","type":"single","widget":"text","selected":"","label":"Text","machine_name":"button_text_2"},
                        "href":{"value":"","type":"single","widget":"text","selected":"","label":"Link"}
                    },"label":"Button","machine_name":"button2","wrapper":"<a class=\"btn btn-secondary btn-md overflow-hide-txt d-block mt-30\" href=\"[LINK]\">[CONTENT]</a>"},"machine_name":"button2","wrapper":"none"
            },"element_type":"single","label":"Button 2","machine_name":"button_2_master","wrapper":"none"},

        "button3":{"elements":{
                0:{"properties":{"val":{"value":"Program Packages","type":"single","widget":"text","selected":"","label":"Text","machine_name":"button_text_3"},
                        "href":{"value":"","type":"single","widget":"text","selected":"","label":"Link"}
                    },"label":"Button","machine_name":"button3","wrapper":"<a class=\"btn btn-secondary btn-md overflow-hide-txt d-block mt-30\" href=\"[LINK]\">[CONTENT]</a>"},"machine_name":"button3","wrapper":"none"
            },"element_type":"single","label":"Button 3","machine_name":"button_3_master","wrapper":"none"}
    },
    "internal_properties":{"type":"section1","html":""}};
