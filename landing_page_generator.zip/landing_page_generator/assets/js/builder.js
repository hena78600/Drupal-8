jQuery(document).ready(function(){
  jQuery("#right").on("click", "a", function(event) {
    //console.log("Testing");
    event.preventDefault();

  });
  jQuery("#pop-up-add").click(function(){
    //close_add_popup();
    jQuery("#pop-up-add").hide();
  });
  jQuery("#add-popup").click(function(e){
    e.stopPropagation();
  });

  jQuery("#image-modal").click(function(){
    //close_add_popup();
    jQuery("#image-modal").hide();
  });
  jQuery("#section-image-popup").click(function(e){
    e.stopPropagation();
  });
  jQuery(document).on('submit','.image-upload-widget form',(function(e) {
    e.preventDefault();
    //alert("Form Submit");
    //landing_page_generator/upload-media-files
    /*jQuery.ajax({
      url: drupalSettings.landing_page_generator.basepath+"/landing_page_generator/upload-media-files",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
      cache: false,
      processData:false,
      success: function(data){
        //alert(data)
        var image_field_name = data.image_field_name;
        var file_name = data.file_name;
        jQuery("#"+image_field_name).val(file_name);
      },
      uploadProgress: function (event, position, total, percentComplete){
       console.log("Complete Percentage: "+percentComplete);
      },
      error: function(){}
    });*/jQuery(this).ajaxSubmit({
      target:   '#targetLayer',
      contentType: false,
      beforeSubmit: function() {
        //$("#progress-bar").width('0%');
        jQuery("#uploadLoader").show();
        jQuery("#progressBar").css("display","block");
        jQuery("#uploadsuccess").css("display","none");
        jQuery("#progressBar").width(0+"%");
      },
      uploadProgress: function (event, position, total, percentComplete){
        //$("#progress-bar").width(percentComplete + '%');
        //$("#progress-bar").html('<div id="progress-status">' + percentComplete +' %</div>')
        console.log("Complete Percentage: "+percentComplete);
        jQuery("#progressBar").width(percentComplete+"%");
      },
      complete:function (data){
        //$('#loader-icon').hide();
        var image_field_name = data.responseJSON.image_field_name;
        var file_name = data.responseJSON.file_name;
        jQuery("#"+image_field_name).val(file_name);
        jQuery("#progressBar").css("display","none");
        jQuery("#uploadLoader").css("display","none");
        jQuery("#uploadsuccess").css("display","block");
      },
      resetForm: true
    });
    //return false;
  }));
  
});

var select_element_id = "right";
var next_element_id = 1;



function remove_element() {
  if(select_element_id != "right") {
    var dialog = confirm("Are you sure you want to delete this section?");
    if (dialog == true) {
      jQuery("#" + select_element_id).remove();
      delete select_elements_object[select_element_id];
      jQuery("#element-properties").html("");
      select_element_id = "right";
    }
  }
}


function escapeRegExp(string){
  return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/* Define functin to find and replace specified term with replacement string */
function replaceAll(str, term, replacement) {
  return str.replace(new RegExp(escapeRegExp(term), 'g'), replacement);
}
function update_data() {
  //jQuery("border-none").replaceAll("border-red");
  jQuery("#loader").show();
  var html = jQuery("#right").html();
  html = replaceAll(html,"border-red"," ");
  var css = jQuery("#css_textarea").val();
  var nid = jQuery("#nid").val();
  var select_object_json = JSON.stringify(select_elements_object);
  var show_header = 0;
  if(jQuery("#show_header").is(":checked") == true) {
    show_header = 1;
  }
  jQuery.ajax({
    method: "POST",
    url: drupalSettings.landing_page_generator.basepath+"/landing_page_generator/update_html",
    data: { html_data: html, nid: nid, select_object: select_object_json, css_data: css, show_header: show_header  }
  })
  .done(function( msg ) {
    jQuery("#loader").hide();
    alert("Data Saved:");
   });
}
function image_widget_upload(form_id) {
  //alert("Testing");
  jQuery("#form-"+form_id).submit();
}
function show_add_popup(element_name) {
  var class_name = element_name;
  var nid = jQuery("#nid").val();
  var popup_html="<div class='container w-100'>";
  jQuery("#pop-up-add").show();
  var local_object = JSON.parse(JSON.stringify(eval(class_name)));
  for(index in local_object.show_properties) {
    propertie = local_object.show_properties[index]['elements'];
    if(local_object.show_properties[index]["element_type"] == "multiple") {
      popup_html += "<div id='"+local_object.show_properties[index]["machine_name"]+"' class=\"pop-up-heading\">";
      popup_html += "<div class=\""+local_object.show_properties[index]["machine_name"]+" pt-20 pb-10 border-top border-bottom\">";
      popup_html += "<div class=\"row\" style=\"padding-bottom: 10px;\">";
      popup_html += "<div class=\"col-md-12\"><h1>"+local_object.show_properties[index]['label']+"</h1></div>";
      var loop_index = 1;
      for (index2 in propertie) {
        for (index3 in propertie[index2]['properties']) {
          popup_html += "<div class='col-md-2'>" + propertie[index2]['properties'][index3]['label'] + "</div>";
          if (propertie[index2]['properties'][index3]['widget'] == "text") {
            popup_html += "<div class='col-md-10 pb-10'><input class=\"form-control\" type='text' id='"+propertie[index2]['machine_name']+"-"+index3+"-"+loop_index+"'></div>";
          }
          else if (propertie[index2]['properties'][index3]['widget'] == "textarea") {
            popup_html += "<div class='col-md-10 pb-10'><textarea class=\"form-control\" id='"+propertie[index2]['machine_name']+"-"+index3+"-"+loop_index+"'></textarea><script>CKEDITOR.replace( '"+propertie[index2]['machine_name']+"-"+index3+"-"+loop_index+"' );</script></div>";
          }
          else if (propertie[index2]['properties'][index3]['widget'] == "image") {
            popup_html += "<div class='col-md-6 pb-10'><input type='text' class=\"form-control\" id='"+propertie[index2]['machine_name']+"-"+index3+"-"+loop_index+"'></div><div class='col-md-1 pr-0 pl-0 image-upload-widget'><form method='post' id='form-"+propertie[index2]['machine_name']+"-"+index3+"-"+loop_index+"' action='/landing_page_generator/upload-media-files'><input type='hidden' name='nid' value='"+nid+"'><input type='hidden' value='"+propertie[index2]['machine_name']+"-"+index3+"-"+loop_index+"' name='image_field_name'><label class='fileContainer'>Browse<input onchange='image_widget_upload(\""+propertie[index2]['machine_name']+"-"+index3+"-"+loop_index+"\");' name='userImage' type='file' class='inputFile'></label></form></div><div class='col-md-3'><div id='uploadLoader'><div id='progressBar'></div></div><div id='uploadsuccess'>Upload Succesful</div></div>";
          }
          else if (propertie[index2]['properties'][index3]['widget'] == "editor") {
            popup_html += "<div class='col-md-10 pb-10'><textarea class=\"form-control\" id='"+propertie[index2]['machine_name']+"-"+index3+"-"+loop_index+"'></textarea><script>CKEDITOR.replace( '"+propertie[index2]['machine_name']+"-"+index3+"-"+loop_index+"' );</script></div>";
          }
        }
      }
      popup_html += "</div>";
      popup_html += "</div>";
      popup_html += "</div>";
      popup_html += "<div class=\"row text-right pt-10\"><div class=\"col-md-12\"><span class='btn btn-warning' onclick=\"add_more_elements('"+class_name+"','"+local_object.show_properties[index]['machine_name']+"')\">+ Add More</span></div></div>";
    }
    else {
      popup_html += "<div id='"+local_object.show_properties[index]["machine_name"]+"' class=\"pop-up-heading\">";
      popup_html += "<div class='row' style='padding-bottom: 10px;'>";
      popup_html += "<div class=\"col-md-12\"><h1>"+local_object.show_properties[index]['label']+"</h1></div>";
      for (index2 in propertie) {
        for (index3 in propertie[index2]['properties']) {
          popup_html += "<div class='col-md-2'>" + propertie[index2]['properties'][index3]['label'] + "</div>";
          if (propertie[index2]['properties'][index3]['widget'] == "text") {
            popup_html += "<div class='col-md-10 pb-10'><input class=\"form-control\" type='text' id='"+propertie[index2]['machine_name']+"-"+index3+"'></div>";
          }
          else if (propertie[index2]['properties'][index3]['widget'] == "textarea") {
            popup_html += "<div class='col-md-10 pb-10'><textarea class=\"form-control\" id='"+propertie[index2]['machine_name']+"-"+index3+"'></textarea><script>CKEDITOR.replace( '"+propertie[index2]['machine_name']+"-"+index3+"' );</script></div>";
          }
          else if (propertie[index2]['properties'][index3]['widget'] == "image") {

            popup_html += "<div class='col-md-6 pb-10'><input class=\"form-control\" type='text' id='"+propertie[index2]['machine_name']+"-"+index3+"'></div><div class='col-md-1 pr-0 pl-0 image-upload-widget'><form method='post' id='form-"+propertie[index2]['machine_name']+"-"+index3+"' action='/landing_page_generator/upload-media-files'><input type='hidden' name='nid' value='"+nid+"'><input  type='hidden' value='"+propertie[index2]['machine_name']+"-"+index3+"' name='image_field_name'><label class='fileContainer'>Browse<input onchange='image_widget_upload(\""+propertie[index2]['machine_name']+"-"+index3+"\")' name='userImage' type='file' class='inputFile'></label></form></div><div class='col-md-3'><div id='uploadLoader'><div id='progressBar'></div></div><div id='uploadsuccess'>Upload Succesful</div></div>";
          }
          else if (propertie[index2]['properties'][index3]['widget'] == "editor") {
            popup_html += "<div class='col-md-10 pb-10'><textarea class=\"form-control\" id='"+propertie[index2]['machine_name']+"-"+index3+"'></textarea><script>CKEDITOR.replace( '"+propertie[index2]['machine_name']+"-"+index3+"' );</script></div>";
          }
          else if (propertie[index2]['properties'][index3]['widget'] == "select") {
            var option_str = "";
            for (var option_value in propertie[index2]['properties'][index3]['option']) {
              var test = "";
              test = option_value;
              option_str += "<option value='"+option_value+"'>"+propertie[index2]['properties'][index3]['option'][option_value]+"</option>"
            }
            popup_html += "<div class='col-md-10 pb-10'><select id='"+propertie[index2]['machine_name']+"-"+index3+"'>"+option_str+"</select></div>";
          }
        }
      }
      popup_html += "</div>";
      popup_html += "</div>";
    }
  }
  popup_html += "<div class='row pb-20 text-right'><div class='col-md-12'><input class='btn btn-primary' type='button' name='create' value='Create' onclick=\"create_element('"+class_name+"')\" style='margin-right: 15px;'><input class='btn btn-danger' type='button' name='close' value='Close' onclick='close_add_popup();'\"></div></div>";
  popup_html += "</div>";
  jQuery("#add-popup").html(popup_html);

}

function add_more_elements(class_name,element_machine_name) {
  //alert(element_machine_name);
  var object = eval(class_name);
  var html = "";
  var next_id = 0;
  jQuery("."+element_machine_name).each(function() {
    next_id = next_id + 1;
  });
  next_id++;
  html += "<div class='"+element_machine_name+" pt-20 pb-10 border-top border-bottom'>";
  for (index in object.show_properties) {
    if(object.show_properties[index]['machine_name'] == element_machine_name) {
      for (index2 in object.show_properties[index]['elements']) {
        for (index3 in object.show_properties[index]['elements'][index2]['properties']) {
          html += "<div class='row' style='padding-bottom: 10px;'><div class='col-md-2'>" + object.show_properties[index]['elements'][index2]['properties'][index3]['label'] + "</div>";
          if (object.show_properties[index]['elements'][index2]['properties'][index3]['widget'] == "text") {
            html += "<div class='col-md-10'><input class=\"form-control\" type='text' id='"+object.show_properties[index]['elements'][index2]['machine_name']+"-"+index3+"-"+next_id+"'></div>";
          }
          else if (object.show_properties[index]['elements'][index2]['properties'][index3]['widget'] == "textarea") {
            html += "<div class='col-md-10'><textarea  class=\"form-control\" id='"+object.show_properties[index]['elements'][index2]['machine_name']+"-"+index3+"-"+next_id+"'></textarea><script>CKEDITOR.replace( '"+object.show_properties[index]['elements'][index2]['machine_name']+"-"+index3+"-"+next_id+"' );</script></div>";
          }
          else if (object.show_properties[index]['elements'][index2]['properties'][index3]['widget'] == "image") {

            html += "<div class='col-md-6'><input class=\"form-control\" type='text' id='"+object.show_properties[index]['elements'][index2]['machine_name']+"-"+index3+"-"+next_id+"'></div><div class='col-md-1 pr-0 pl-0 image-upload-widget'><form method='post' id='form-"+object.show_properties[index]['elements'][index2]['machine_name']+"-"+index3+"-"+next_id+"' action='/landing_page_generator/upload-media-files'><input type='hidden' name='nid' value='"+nid+"'><input  type='hidden' value='"+object.show_properties[index]['elements'][index2]['machine_name']+"-"+index3+"-"+next_id+"' name='image_field_name'><label class='fileContainer'>Browse<input onchange='image_widget_upload(\""+object.show_properties[index]['elements'][index2]['machine_name']+"-"+index3+"-"+next_id+"\")' name='userImage' type='file' class='inputFile'></label></form></div><div class='col-md-3'><div id='uploadLoader'><div id='progressBar'></div></div><div id='uploadsuccess'>Upload Succesful</div></div>";
          }
          else if (propertie[index2]['properties'][index3]['widget'] == "editor") {
            popup_html += "<div class='col-md-10 pb-10'><textarea class=\"form-control\" id='"+propertie[index2]['machine_name']+"-"+index3+"-"+loop_index+"'></textarea><script>CKEDITOR.replace( '"+object.show_properties[index]['elements'][index2]['machine_name']+"-"+index3+"-"+next_id+"' );</script></div>";
          }
          html += "</div>";
        }
      }
    }
  }
  html += "<div class=\"row text-right\">\n" +
      "      <div class=\"col-md-12\">\n" +
      "\t<a class=\"btn btn-danger btn-remove\" onclick=\"remove_multiple_item(this)\"><span>x</span> Remove Section</a>\n" +
      "\t</div>\n" +
      "   </div></div>";
  jQuery("#"+element_machine_name).append(html);
  var a =0;
}


function remove_multiple_item(object) {
  var remove_element = jQuery(object).parent().parent().parent();
  jQuery(remove_element).remove();
}

function create_element(element_class_name) {
  var object = eval(element_class_name);
  jQuery.get("/modules/custom/landing_page_generator/assets/templates/"+element_class_name+".html",function (content) {
    for (index in object['show_properties']) {
      var machine_name = object['show_properties'][index]['machine_name'];
      if(object['show_properties'][index]['wrapper'] == "none") {
        for (index2 in object['show_properties'][index]['elements']) {
          if(object['show_properties'][index]['elements'][index2]['wrapper'] == "none") {
            for (index3 in object['show_properties'][index]['elements'][index2]['properties']) {
              if (object['show_properties'][index]['element_type'] == "single") {
                var properties_machine_name = object['show_properties'][index]['elements'][index2]['machine_name'];
                if(object['show_properties'][index]['elements'][index2]['properties'][index3]['widget'] == "editor" || object['show_properties'][index]['elements'][index2]['properties'][index3]['widget'] == "textarea") {
                  var ckeditor_instance = CKEDITOR.instances;
                  var replace_content = ckeditor_instance[properties_machine_name + "-" + index3].getData();
                }
                else {
                  var replace_content = jQuery("#" + properties_machine_name + "-" + index3).val();
                }
                content = content.replace("[" + machine_name + "]", replace_content);
                content = content.replace("[ELEMENT_ID]", next_element_id);

              }
              else if (object['show_properties'][index]['element_type'] == "multiple") {

              }
            }
          }
          else {
            var child_wrapper = "";
            var temp_wrapper = "";
            //child_wrapper += object['show_properties'][index]['elements'][index2]['wrapper'];
            temp_wrapper += object['show_properties'][index]['elements'][index2]['wrapper'];
            for(index3 in object['show_properties'][index]['elements'][index2]['properties']) {
              var properties_machine_name = object['show_properties'][index]['elements'][index2]['machine_name'];
              //var replace_content = jQuery("#" + properties_machine_name+"-"+index3).val();
              if(object['show_properties'][index]['elements'][index2]['properties'][index3]['widget'] == "editor" || object['show_properties'][index]['elements'][index2]['properties'][index3]['widget'] == "textarea") {
                var ckeditor_instance = CKEDITOR.instances;
                var replace_content = ckeditor_instance[properties_machine_name + "-" + index3].getData();
              }
              else {
                var replace_content = jQuery("#" + properties_machine_name + "-" + index3).val();
              }
              if(replace_content != "") {
                if (index3 == 'href') {
                  temp_wrapper = temp_wrapper.replace('[LINK]', replace_content);

                }
                else if (index3 == "poster") {
                  temp_wrapper = temp_wrapper.replace('[POSTER]', replace_content);
                }
                else {
                  temp_wrapper = temp_wrapper.replace('[CONTENT]', replace_content);
                }
              }
              else {
                temp_wrapper = "";
              }
            }
            child_wrapper += temp_wrapper;
            temp_wrapper = "";
            content = content.replace("["+machine_name+"]",child_wrapper);
            content = content.replace("[ELEMENT_ID]", next_element_id);
          }
        }
      }
      else {
        var master_wrapper = "";
        var child_wrapper = "";
        var temp_wrapper = "";
        if (object['show_properties'][index]['element_type'] == "single") {
          master_wrapper += object['show_properties'][index]['wrapper'];
          for (index2 in object['show_properties'][index]['elements']) {
            //child_wrapper += object['show_properties'][index]['elements'][index2]['wrapper'];
            temp_wrapper += object['show_properties'][index]['elements'][index2]['wrapper'];
            for(index3 in object['show_properties'][index]['elements'][index2]['properties']) {
              var properties_machine_name = object['show_properties'][index]['elements'][index2]['machine_name'];
              //var replace_content = jQuery("#" + properties_machine_name+"-"+index3).val();
              if(object['show_properties'][index]['elements'][index2]['properties'][index3]['widget'] == "editor" || object['show_properties'][index]['elements'][index2]['properties'][index3]['widget'] == "textarea") {
                var ckeditor_instance = CKEDITOR.instances;
                var replace_content = ckeditor_instance[properties_machine_name + "-" + index3].getData();
              }
              else {
                var replace_content = jQuery("#" + properties_machine_name + "-" + index3).val();
              }
              if(replace_content != "") {
                if (index3 == 'href') {
                  temp_wrapper = temp_wrapper.replace('[LINK]', replace_content);

                }
                else if (index3 == "poster") {
                  temp_wrapper = temp_wrapper.replace('[POSTER]', replace_content);
                }
                else {
                  temp_wrapper = temp_wrapper.replace('[CONTENT]', replace_content);
                }
              }
              else {
                temp_wrapper = "";
              }
            }
            child_wrapper += temp_wrapper;
            temp_wrapper = "";
            //content += content.replace("["+machine_name+"]",replace_content);
          }
          if(object['show_properties'][index]['wrapper'] != "none") {
            //alert(child_wrapper);
            master_wrapper = master_wrapper.replace('[CONTENT]', child_wrapper);
          }
          else {
            master_wrapper += child_wrapper;
          }
        }
        else if (object['show_properties'][index]['element_type'] == "multiple") {
          //var properties_machine_name = object['show_properties'][index]['elements'][index2]['machine_name'];
          var element_count = 1;
          jQuery("."+machine_name).each(function () {
            master_wrapper += object['show_properties'][index]['wrapper'];
            for(index2 in object['show_properties'][index]['elements']) {
              var properties_machine_name = object['show_properties'][index]['elements'][index2]['machine_name'];
              var temp_wrapper = "";
              temp_wrapper += object['show_properties'][index]['elements'][index2]['wrapper'];
              //child_wrapper += object['show_properties'][index]['elements'][index2]['wrapper'];
              for(index3 in object['show_properties'][index]['elements'][index2]['properties']) {
                //var replace_content = jQuery("#" + properties_machine_name + "-"+index3+"-" + element_count).val();
                if(object['show_properties'][index]['elements'][index2]['properties'][index3]['widget'] == "editor" || object['show_properties'][index]['elements'][index2]['properties'][index3]['widget'] == "textarea") {
                  var ckeditor_instance = CKEDITOR.instances;
                  var replace_content = ckeditor_instance[properties_machine_name + "-" + index3 + "-" + element_count].getData();
                }
                else {
                  var replace_content = jQuery("#" + properties_machine_name + "-" + index3 + "-" + element_count).val();
                }
                if(replace_content != "") {
                  if (index3 == 'href') {
                    temp_wrapper = temp_wrapper.replace('[LINK]', replace_content);

                  }
                  else if (index3 == "poster") {
                    temp_wrapper = temp_wrapper.replace('[POSTER]', replace_content);
                  }
                  else {
                    temp_wrapper = temp_wrapper.replace('[CONTENT]', replace_content);
                  }
                }
                else {
                  temp_wrapper = "";
                }
              }
              child_wrapper += temp_wrapper;
              temp_wrapper = "";
            }
            master_wrapper = master_wrapper.replace('[CONTENT]',child_wrapper);
            child_wrapper = "";
            element_count++;
            //master_wrapper = "";
          });
        }
        console.log("testing");
        content = content.replace("["+machine_name+"]",master_wrapper);
        content = content.replace("[ELEMENT_ID]", next_element_id);
      }
    }
    next_element_id = next_element_id + 1;
    jQuery("#right").append(content);
    jQuery("#pop-up-add").hide();
  },'html');

}
function close_add_popup() {
  jQuery("#pop-up-add").hide();
}

function show_section_image(image_url) {
  jQuery("#image-modal").show();
  jQuery("#section-image-popup .showDesign").html("<img src='"+image_url+"' class='img-responsive' /><br/><input type='button' class='btn btn-danger' value='close' onclick='close_image_popup();'/>");
}

function close_image_popup() {
  jQuery("#image-modal").hide();
}

function show_media_libraray() {
  window.open('https://www.staging-5em2ouy-3hub5ssgngtw6.us-2.platformsh.site/landing_page_generator/media', '_blank');
}

function close_media_popup() {
  jQuery("#show-media-libraray").hide();
}
function show_css_editor_popup() {
  jQuery("#css-editor").show();
}
function close_css_popup() {
  jQuery("#css-editor").hide();
}
function update_css() {
  jQuery("#css-editor").hide();
}

function chose_image(id_index,image_text_box_id) {
  var image_container_id = "#load-image";
  if(id_index != 0) {
    image_container_id = image_container_id+ "-" + id_index;
  }
  var image_name = "";
  image_name = jQuery("#"+id_index+"-load-search-image").val();
  jQuery(image_container_id).show();
  jQuery(image_container_id+" .image-container").html("<div id='image-loader'><img src='/modules/custom/landing_page_generator/assets/img/loading.gif'></div>");
  jQuery.get('/landing_page_generator/get-media-images', {text_id: image_text_box_id,container_id:id_index, image_name:image_name})
      .done(function(response) {
        //alert("success");
        jQuery(image_container_id+" .image-container").html(response.data);
      });
}

function select_media_image(image_object,image_text_box_id,id_index) {
  var image_container_id = "#load-image";
  if(id_index != 0) {
    image_container_id = image_container_id+ "-" + id_index;
  }
  jQuery(image_container_id).hide();
  var image_url = jQuery(image_object).data('path');
  jQuery("#"+image_text_box_id).val(image_url);

}

function close_media_image_section(id_index) {
  var image_container_id = "#load-image";
  if(id_index != 0) {
    image_container_id = image_container_id+ "-" + id_index;
  }
  jQuery(image_container_id).hide();
}
function bubbleSort(array) {
  var done = false;
  while (!done) {
    done = true;
    for (var i = 1; i < array.length; i += 1) {
      if (array[i - 1] > array[i]) {
        done = false;
        var tmp = array[i - 1];
        array[i - 1] = array[i];
        array[i] = tmp;
      }
    }
  }

  return array;
}
function rearrange_sections() {
  var section_count = jQuery("#right").find("[data-parent='1']").length;
  var weight_array = [];
  var index_count = 0;
  jQuery("[data-parent='1']").each(function () {
    var section_weight = jQuery(this).attr('data-weight');
    weight_array[index_count] = parseInt(section_weight);
    index_count++;
  });
  weight_array = bubbleSort(weight_array);
  var i = 0;
  var validation_error = 0;
  for (i=0;i<weight_array.length;i++) {
    if(jQuery("#right").find("[data-weight='"+weight_array[i]+"']").length > 1) {
      validation_error = 1;
      break;
    }
  }
  var rearrange_html = "";
  if(validation_error == 0) {
    for (i = 0; i < weight_array.length; i++) {
      //var section_id = jQuery("#right").find("[data-weight='"+weight_array[i]+"']")[0].id;
      var section_object = jQuery("#right").find("[data-weight='" + weight_array[i] + "']");
      rearrange_html += jQuery("#right").find("[data-weight='" + weight_array[i] + "']")[0].outerHTML;
    }
    jQuery("#right").html(rearrange_html);
  }
  else {
    alert("Please remove duplicate weight");
  }

}

function show_edit_popup() {
  var html = "<div class='row'>";
  if(select_object == "") {
    alert("Please select a element!");
  }
  else {
    var element_value = select_object.innerHTML;
    var element_type = select_object.localName;
    if (element_type == "a") {
      var link = select_object.href;
      html += "<div class='col-md-2'><label>Value</label> </div><div class='col-md-10'><textarea class=\"form-control\" id='edit-element-text'>" + element_value + "</textarea></div>";
      html += "<div class='col-md-2'><label>Link</label> </div><div class='col-md-10'><input type='text' class=\"form-control\" id='edit-element-link' value='" + link + "'></div>";
      html += "<div class='col-md-12 pb-10 mt-20 text-right'><input type='button' value='Update' class='btn btn-primary mr-10' onclick='update_element_value()'> <input type='button' value='Close' class='btn btn-warning' onclick='close_edit_popup()'></div>";

      html += "</div>";

    }
    else if (element_type == "img") {
      html += "<div class='col-md-2'><label>Image</label> </div><div class='col-md-10'><input class=\"form-control\" type='text' id='card_image-html-edit' /></div>";
      html += "<div class='col-md-2'></div><div class='col-md-10'><a href=\"#\" onclick=\"chose_image('edit','card_image-html-edit')\">Chose Image</a></div>";
      html += "<div class='col-md-2'></div><div class='col-md-10'><div class=\"load-image\" id=\"load-image-edit\"><div class='image-search'><input type='text' name='search' id='load-search-image'><input type='button' value='Search' onclick='chose_image(\"edit\",\"card_image-html-edit\")'></div><div class=\"image-container\"></div><div class=\"select-image-button\"><input type=\"button\" class=\"btn btn-primary\" value=\"Close\" onclick=\"close_media_image_section('edit')\"></div></div></div>";
      html += "<div class='col-md-12 pb-10 pb-10 mt-20 text-right'><input type='button' value='Update' class='btn btn-primary mr-10' onclick='update_element_value()'> <input type='button' value='Close' class='btn btn-warning' onclick='close_edit_popup()'></div>";
      html += "</div>";
    }
    else {
      html += "<div class='col-md-2'><label>Value</label> </div><div class='col-md-10'><textarea class=\"form-control\" id='edit-element-text'>" + element_value + "</textarea><script>CKEDITOR.replace( 'edit-element-text' );</script></div>";
      html += "<div class='col-md-12 pb-10 mt-20 text-right'><input type='button' value='Update' class='btn btn-primary mr-10' onclick='update_element_value()'><input  type='button' value='Close' class='btn btn-warning' onclick='close_edit_popup()'></div>";
      html += "</div>";
    }
    jQuery("#edit-popup").html(html);
    jQuery("#edit-popup").show();
  }
}
function update_element_value() {
  var update_value = jQuery("#edit-element-text").val();
  var element_type = select_object.localName;
  if(element_type == "a") {
    var link = jQuery("#edit-element-link").val();
    jQuery(select_object).text(update_value);
    jQuery(select_object).attr("href",link);
  }
  else if(element_type == "img") {
    var src = jQuery("#card_image-html-edit").val();
    jQuery(select_object).attr("src",src);
  }
  else {
    var ckeditor_instance = CKEDITOR.instances;
    update_value = ckeditor_instance['edit-element-text'].getData();
    jQuery(select_object).html(update_value);
  }
  jQuery("#edit-popup").hide();

}
function close_edit_popup() {
  jQuery("#edit-popup").html(" ");
  jQuery("#edit-popup").hide();
}



/*
var myDropzone = new Dropzone("div#myDropZone", { url: "/landing_page_generator/upload-media-files"});
*/
Dropzone.options.myAwesomeDropzone = {
  paramName: "file", // The name that will be used to transfer the file
  maxFilesize: 10, // MB
  accept: function(file, done) {
    if (file.type == "image/png" || file.type == "image/jpg" || file.type == "image/jpeg" || file.type == "image/gif" || file.type == "image/svg+xml" || file.type == "video/mp4" || file.type == "application/pdf" || file.type == "application/vnd.openxmlformats-officedocument.presentationml.presentation" || file.type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document" || file.type == "application/msword") {
      done();
    }
    else { done("File type is not supported"); }
  }
};
