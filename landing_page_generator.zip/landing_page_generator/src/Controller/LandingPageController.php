<?php

namespace Drupal\landing_page_generator\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\node\Entity\Node;
use Drupal\Core\Site\Settings;

/**
 * Class LandingPageController.
 */
class LandingPageController extends ControllerBase {

  /**
   * Showlandingpagebuilder.
   *
   * @return string
   *   Return Hello string.
   */
  public function showLandingPageBuilder() {
    $a = 0;
    $nid = $_GET['nid'];
    $current_path = \Drupal::service('path.current')->getPath();
    if(!empty($nid)) {
     // $connection = \Drupal::database();
      //$fetch_data_obj = $connection->query("SELECT * FROM landing_page_builder WHERE nid = :nid", [':nid' => $nid])->fetchObject();
      $html = '';
      $select_object = '';
      $fetch_status = 0;
      /*if(!empty($fetch_data_obj)) {
        $html = $fetch_data_obj->html;
        $select_object = $fetch_data_obj->select_object;
        $fetch_status = 1;
        $select_object = str_replace("'","\'",$select_object);
      }*/
      $node = Node::load($nid);
      $html = $node->field_landing_page_body->getValue()[0]['value'];
      $css = $node->field_css->getValue()[0]['value'];
      $settings = json_decode($node->field_settings->getValue()[0]['value']);
      $country_code = Settings::get('site_code', '');
      $country_code = '/'.$country_code;
      if($country_code == "/database") {
        $country_code = "";
      }
      $build = [
        '#theme' => 'langing_page_builder',
        '#attached' => [
          'library' => [
            'landing_page_generator/landing-page-builder-styles',
          ]
        ],
        '#data' => ['html' => $html,'css'=>$css,'nid' => $nid, 'select_object' => $select_object,'fetch_status' => $fetch_status,'current_path' => $current_path,'settings' => $settings,'country_code' => $country_code
        ]
      ];

      $build['#cache']['max-age'] = 0;

      return $build;
    }
    else {
      $build = [
        '#markup' => 'Something Wrong! Go to <a class="btn btn-primary" href="/admin/content">content page</a>',
        '#attached' => [
          'library' => [
            'landing_page_generator/landing-page-builder-styles',
          ]
        ]
      ];
      return $build;
    }

  }

  public function updateHtml() {
    $data = $_POST['html_data'];
    $nid  = $_POST['nid'];
    $css = $_POST['css_data'];
    $show_header = $_POST['show_header'];
    $select_object = $_POST['select_object'];
    $settings = array();
    $settings['show_header'] = $show_header;
    //$entity = \Drupal::entityTypeManager()->getStorage("node")->load($nid);
    $node = Node::load($nid);
    $node->set("field_landing_page_body", $data); // also tried $node->setTitle('The new Title');
    $node->set("field_css",$css);
    $node->set("field_settings",json_encode($settings));
    $node->save();
    /*$connection = \Drupal::database();
    $fetch_data_obj = $connection->query("SELECT * FROM landing_page_builder WHERE nid = :nid", [':nid' => $nid])->fetchObject();
    if(empty($fetch_data_obj)) {
      $query = $connection->insert('landing_page_builder')->fields([
        'nid',
        'html',
        'select_object'
      ])->values(['nid' => $nid, 'html' => $data, 'select_object' => $select_object]);
      $query->execute();
    }
    else {
      $connection->update('landing_page_builder')
        ->fields([
          'nid' => $nid,
          'html' => $data,
          'select_object' => $select_object
        ])
        ->condition('nid', $nid, '>=')
        ->execute();
    }*/
    $build = [
      '#markup' => $this->t('Update Successful'),
    ];
    return $build;
  }

  public function get_media_images() {
    $text_box_id = $_GET['text_id'];
    $image_container_id = $_GET['container_id'];
    $image_name = $_GET['image_name'];
    $base_path =  dirname(__FILE__);
    $base_path .= '/../../../../../sites/default/files/landingpagegenerator/';
    $scanned_directory = array_diff(scandir($base_path), array('..', '.'));
    $html = "";
    $html = "<div class='row'>";
    $counter = 0;
    $all_image_counter = 0;
    foreach ($scanned_directory as $item) {
      if (empty($image_name)) {
        $all_image_counter++;
        if($all_image_counter > 30) {
          break;
        }
        /*if ($counter % 3 == 0 && $counter == 0) {
          $html .= "<div class='row'>";
        }
        elseif ($counter % 3 == 0) {
          $html .= "</div><div class='row'>";
        }*/
        $ext = pathinfo($item, PATHINFO_EXTENSION);
        $file_name = pathinfo($item, PATHINFO_FILENAME);
        if ($ext == "mp4") {
          $html .= "<div class='col-md-4'><video onclick='select_media_image(this,\"" . $text_box_id . "\",\"" . $image_container_id . "\")' src='/sites/default/files/landingpagegenerator/" . $item . "' class='img-thumbnail' data-path='/sites/default/files/landingpagegenerator/" . $item . "'></video></div>";

        }
        else {
          $a = 0;
          if ($ext == "jpg" || $ext == "gif" || $ext == "png" || $ext == "svg" || $ext == "jpeg") {
            $html .= "<div class='col-md-4'><img data-path='/sites/default/files/landingpagegenerator/" . $item . "' title='" . $file_name . "." . $ext . "' onclick='select_media_image(this,\"" . $text_box_id . "\",\"" . $image_container_id . "\")' src='/sites/default/files/landingpagegenerator/" . $item . "' class='img-thumbnail'></div>";
          }
          else {
            switch ($ext) {
              case "pdf":
                $html .= "<div class='col-md-4'><img data-path='/sites/default/files/landingpagegenerator/" . $item . "' title='" . $file_name . "." . $ext . "' onclick='select_media_image(this,\"" . $text_box_id . "\",\"" . $image_container_id . "\")' src='/modules/custom/landing_page_generator/assets/img/pdf_icon.png' class='img-thumbnail'></div>";
                break;
              case "pptx":
                $html .= "<div class='col-md-4'><img data-path='/sites/default/files/landingpagegenerator/" . $item . "' title='" . $file_name . "." . $ext . "' onclick='select_media_image(this,\"" . $text_box_id . "\",\"" . $image_container_id . "\")' src='/modules/custom/landing_page_generator/assets/img/pptx_icon.png' class='img-thumbnail'></div>";
                break;
              case  "docx":
                $html .= "<div class='col-md-4'><img data-path='/sites/default/files/landingpagegenerator/" . $item . "' title='" . $file_name . "." . $ext . "' onclick='select_media_image(this,\"" . $text_box_id . "\",\"" . $image_container_id . "\")' src='/modules/custom/landing_page_generator/assets/img/docx_icon.png' class='img-thumbnail'></div>";
                break;
              case "doc":
                $html .= "<div class='col-md-4'><img data-path='/sites/default/files/landingpagegenerator/" . $item . "' title='" . $file_name . "." . $ext . "' onclick='select_media_image(this,\"" . $text_box_id . "\",\"" . $image_container_id . "\")' src='/modules/custom/landing_page_generator/assets/img/doc_icon.png' class='img-thumbnail'></div>";
                break;
              default:
                $html .= "<div class='col-md-4'><img data-path='/sites/default/files/landingpagegenerator/" . $item . "' title='" . $file_name . "." . $ext . "' onclick='select_media_image(this,\"" . $text_box_id . "\",\"" . $image_container_id . "\")' src='/modules/custom/landing_page_generator/assets/img/file_icon.png' class='img-thumbnail'></div>";
                break;
            }
          }
        }
      }
      else {
        $position = strpos($item, $image_name);
        if(is_numeric($position)) {
          $ext = pathinfo($item, PATHINFO_EXTENSION);
          $file_name = pathinfo($item, PATHINFO_FILENAME);
          if ($ext == "mp4") {
            $html .= "<div class='col-md-4'><video onclick='select_media_image(this,\"" . $text_box_id . "\",\"" . $image_container_id . "\")' src='/sites/default/files/landingpagegenerator/" . $item . "' class='img-thumbnail' data-path='/sites/default/files/landingpagegenerator/" . $item . "'></video></div>";

          }
          else {
            $a = 0;
            if ($ext == "jpg" || $ext == "gif" || $ext == "png" || $ext == "svg" || $ext == "jpeg") {
              $html .= "<div class='col-md-4'><img data-path='/sites/default/files/landingpagegenerator/" . $item . "' title='" . $file_name . "." . $ext . "' onclick='select_media_image(this,\"" . $text_box_id . "\",\"" . $image_container_id . "\")' src='/sites/default/files/landingpagegenerator/" . $item . "' class='img-thumbnail'></div>";
            }
            else {
              switch ($ext) {
                case "pdf":
                  $html .= "<div class='col-md-4'><img data-path='/sites/default/files/landingpagegenerator/" . $item . "' title='" . $file_name . "." . $ext . "' onclick='select_media_image(this,\"" . $text_box_id . "\",\"" . $image_container_id . "\")' src='/modules/custom/landing_page_generator/assets/img/pdf_icon.png' class='img-thumbnail'></div>";
                  break;
                case "pptx":
                  $html .= "<div class='col-md-4'><img data-path='/sites/default/files/landingpagegenerator/" . $item . "' title='" . $file_name . "." . $ext . "' onclick='select_media_image(this,\"" . $text_box_id . "\",\"" . $image_container_id . "\")' src='/modules/custom/landing_page_generator/assets/img/pptx_icon.png' class='img-thumbnail'></div>";
                  break;
                case  "docx":
                  $html .= "<div class='col-md-4'><img data-path='/sites/default/files/landingpagegenerator/" . $item . "' title='" . $file_name . "." . $ext . "' onclick='select_media_image(this,\"" . $text_box_id . "\",\"" . $image_container_id . "\")' src='/modules/custom/landing_page_generator/assets/img/docx_icon.png' class='img-thumbnail'></div>";
                  break;
                case "doc":
                  $html .= "<div class='col-md-4'><img data-path='/sites/default/files/landingpagegenerator/" . $item . "' title='" . $file_name . "." . $ext . "' onclick='select_media_image(this,\"" . $text_box_id . "\",\"" . $image_container_id . "\")' src='/modules/custom/landing_page_generator/assets/img/doc_icon.png' class='img-thumbnail'></div>";
                  break;
                default:
                  $html .= "<div class='col-md-4'><img data-path='/sites/default/files/landingpagegenerator/" . $item . "' title='" . $file_name . "." . $ext . "' onclick='select_media_image(this,\"" . $text_box_id . "\",\"" . $image_container_id . "\")' src='/modules/custom/landing_page_generator/assets/img/file_icon.png' class='img-thumbnail'></div>";
                  break;
              }
            }
          }
        }
      }
      $counter++;
    }
    $html .= "</div>";
    return new JsonResponse([
      'data' => $html,
      'method' => 'GET',
    ]);
  }

  public function upload_media_file() {
    $ds          = DIRECTORY_SEPARATOR;
    $base_path =  dirname(__FILE__);
    $base_path .= '/../../../../../sites/default/files/landingpagegenerator/';
    $storeFolder = $base_path;   //2
    $nid = $_POST['nid'];
    $node_path = '/node/' . (int) $nid;
    $langcode = \Drupal::languageManager()->getCurrentLanguage()->getId();
    $path_alias = \Drupal::service('path.alias_manager')->getAliasByPath($node_path, $langcode);
    $path_alias_array = explode("/",$path_alias);
    $folder_name = "";
    $image_field_name = $_POST['image_field_name'];
    foreach ($path_alias_array as $key => $value) {
      if($value != "/" && $value != "") {
        if(count($path_alias_array)-1 == $key) {
          $folder_name .= $value;
        }
        else {
          $folder_name .= $value . "_";
        }
      }
    }
    if (!empty($_FILES)) {

      $tempFile = $_FILES['userImage']['tmp_name'];          //3

      //$targetPath = dirname( __FILE__ ) . $ds. $storeFolder . $ds;  //4
      $file_name = time().'_'.$_FILES['userImage']['name'];
      $targetFile =  $storeFolder.$folder_name.'/'.$file_name;  //5
      $file_type = $_FILES['userImage']['type'];
      $message = "";
      if(!file_exists($base_path.$folder_name)) {
        mkdir($base_path.$folder_name);
        chmod($base_path.$folder_name,0777);
      }
      if (move_uploaded_file($tempFile,$targetFile) && ($file_type == "image/png" || $file_type == "image/jpg" || $file_type == "image/jpeg" || $file_type == "image/gif" || $file_type == "image/svg+xml" || $file_type == "video/mp4" || $file_type== "application/pdf" || $file_type == "application/vnd.openxmlformats-officedocument.presentationml.presentation" || $file_type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document" || $file_type == "application/msword")) {
        $message = "File Uploaded Successfully Done";
      }
      else {
        $message = "File Uploading is not Successful";
      }

    }
    /*$build = [
      '#markup' => '{"file_name":"'.$file_name.'","image_field_name":"'.$image_field_name.'"}',
      '#type' => 'page'
    ];*/
    //return $build;
    $file_name = "/sites/default/files/landingpagegenerator/".$folder_name."/".$file_name;
    return new JsonResponse(array("file_name"=>$file_name,"image_field_name"=>$image_field_name));
  }

  public function media() {
    $country_code = Settings::get('site_code', '');
    $host = $_SERVER["HTTP_HOST"];
    $protocol = strtolower(substr($_SERVER["SERVER_PROTOCOL"],0,strpos( $_SERVER["SERVER_PROTOCOL"],'/'))).'://';
    $checkhost = end(explode(".",$host));
    if ($checkhost == 'local') {
      if($country_code == "database") {
        $site_url = $protocol . $host;
      }
      else {

        $site_url = $protocol . $country_code . '.' . $host;
      }
      define('FM_SELF_URL', $site_url."/landing_page_generator/media");
    }
    else {
      if($country_code == "database") {
        $site_url = "https://" . $host . '/';
      }
      else {
        $site_url = "https://" . $host . '/' . $country_code.'/';
      }
      define('FM_SELF_URL', $site_url."landing_page_generator/media");
    }
      define('FM_EMBED', true);
       // must be set if URL to manager not equal PHP_SELF
      /*define('FM_ROOT_PATH',__DIR__.'/../../../../sites/default/files/landingpagegenerator/');*/
      $path = __DIR__.'/../../includes/tinyfilemanager.php';
      require __DIR__.'/../../includes/tinyfilemanager.php';
    $build = [
      '#markup' => $this->t("testing"),
      "#type" => 'page'
    ];
    return $build;
  }
}

